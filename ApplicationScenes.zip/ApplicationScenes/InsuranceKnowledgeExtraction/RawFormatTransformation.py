#encoding=UTF-8


import argparse
import os
import re
import shutil
import copy
import zipfile
from lxml import etree
import pandas as pd
from sqlalchemy import create_engine

from ApplicationScenes.InsuranceKnowledgeExtraction.tool import getClauseIdentity,getNodeType,getZoneContent
from ApplicationScenes.InsuranceKnowledgeExtraction import hparams

class RawFormatTransformation():

    def __init__(self):
        self.initFramework()
        a=1

    def initFramework(self):
        parser = argparse.ArgumentParser()
        # Add arguments.
        hparams.add_arguments(parser)
        # Acquire param file path.
        self.flags, unused = parser.parse_known_args()

    def unzipDocx(self):
        '''
        Script中的Script 9：将目录下的所有pdf转化为docx——》zip解压
        :return:
        '''
        if os.path.isdir(self.docxFolder):
            fileList = os.listdir(self.docxFolder)
        else:
            fileList = []
            fileList.append(self.docxFolder)

        # docx改名为zip
        for filename in fileList:
            portion = os.path.splitext(filename)  # 分离文件名字和后缀
            print(portion)

            if portion[1] == ".docx":  # 根据后缀来修改,如无后缀则空
                oldname = portion[0] + ".docx"
                newname = portion[0] + ".zip"  # 要改的新后缀
                os.chdir(self.docxFolder)  # 切换文件路径,如无路径则要新建或者路径同上,做好备份
                os.rename(filename, newname)
        # docx用zip解压为文件夹
        zipList = [re.sub(r'(.docx)', '.zip', name) for name in fileList]
        for zipFile in zipList:
            name = os.path.splitext(zipFile)
            if name[1] == '.zip':
                file_zip = zipfile.ZipFile(os.path.join(self.docxFolder, zipFile), 'r')
                tempFolder = os.path.join(self.xmlFolder, 'temp')
                file_zip.extract('word/document.xml', path=tempFolder)
                shutil.move(os.path.join(tempFolder, 'word/document.xml'), \
                            self.xmlFolder + name[0] + '.xml')
        # 删除临时文件夹
        shutil.rmtree(tempFolder)

    def analyzeXML(self, XMLFilePath, write2sql=True):
        '''
        Script中的Script 9：从xml提取出dicHeadingContent（标题，内容），dicTerminology（术语，定义）两个词典，并写入Neo4j
        :return:
        '''
        parser = etree.XMLParser()
        root = etree.parse(XMLFilePath, parser).getroot()
        dicHeadingContent = {}  # 标题和对应的内容存储在里面
        dicTerminology = {}  # 专有名词和对应的解释存储在里面
        # 获取公司名和产品名
        companyName, productName = getClauseIdentity(XMLFilePath)
        dicHeadingContent = {'company': companyName, 'product': productName, 'detail': {}}
        dicTerminology = {'company': companyName, 'product': productName, 'detail': {}}
        # 0.找出所有p节点，作为我们处理的全集
        pList = root.xpath('descendant::w:p', namespaces=root.nsmap)
        terminationList = []
        headingContentList = []
        flagHeading = False
        flagExplanation = False
        # PART1:把p放到对应的区域中
        # 1.定位正文区域的开头：第一个heading1处
        # 2.将正文区域的所有p节点分为2部分：名词定义区域 和 其他区域
        # 名词定义区域：定义分隔符开始的p——紧接着的第一个footer的p
        # 其他区域：包含了子标题和对应的内容
        pLen = len(pList)
        flagContentBegin = False
        for pNode in pList:
            nodeType = getNodeType(pNode, flagHeading, flagExplanation)
            if flagContentBegin == True:
                # content范围内，分隔符和footer之间的是“terminology”，其他都是“headingContent”
                # 如果p是名词解释分隔符——太平人寿产品中出现
                if nodeType == 'ItemExplanationSeparator':
                    print("Separator Begin")
                    flagExplanation = True
                # 如果p是footer:将flagExplanation复原
                elif nodeType == 'Footer':
                    print("Footer happens")
                    flagExplanation = False
                elif nodeType == 'ItemExplanationContent':
                    print("ItemExplanationContent happens")
                    terminationList.append(pNode)
                else:
                    print("HeadingContent happens")
                    headingContentList.append(pNode)
            else:
                # 第一个Heading1之前的都是目录
                if len(pNode.xpath('descendant::w:pStyle[contains(@w:val,"Heading1")]', namespaces=pNode.nsmap)):
                    flagContentBegin = True
                    flagHeading = True
                    headingContentList.append(pNode)
                else:
                    continue

        # PART2:提取各区域的内容
        # 3.从名词定义区域提取内容，存入dicTerminology
        ''''''
        content1 = []
        for pNode in terminationList:
            content1.extend(pNode.xpath('descendant::text()'))
        content = '。' + ''.join(content1)
        content = re.sub('(）)([0-9]{1,})', lambda x: x.group(1) + '。' + x.group(2),
                         content)  # 在所有“右括号+数字”模板如“）9”的右括号后插入一个中文句号
        content = re.split('。[0-9]{1,}', content)

        for item in content:
            if len(item) == 0:
                continue
            else:
                # 替换第一个冒号为名词与定义的分隔符
                temp = re.sub('：', '||', item, count=1)
                key, value = temp.split('||')
                dicTerminology['detail'][key] = value

        # 4.从其他区域抽取内容，存入dicHeadingContent。
        #  处理的是List。要把这个list尽量控制的简单，只有heading和content
        flagExplanation = False
        flagHeading = False
        heading = ''
        lastHeading = ''
        contentZone = []
        explanationZone = []
        for element in headingContentList:
            # 判断当前p是什么类型
            elementType = getNodeType(element, flagHeading, flagExplanation)
            # 如果p是heading
            if elementType == 'Heading':
                print("Headings Begin")
                flagHeading = True
                lastHeading = copy.copy(heading)
                heading = ''.join(element.xpath('descendant::text()'))
                heading = re.sub('\s', '', heading)  # 将所有的空白字符删除
                print("%s" % heading)
                result = re.search('第.{1,}条([\u4e00-\u9fa5]+[\S]{0,})', heading)
                heading = result.group(1) if result != None else heading

                if len(lastHeading) != 0:
                    # 遇到新heading，将内容联系到上一个heading
                    dicHeadingContent['detail'][lastHeading] = getZoneContent(contentZone)
                    contentZone = []
            # 如果p是名词解释分隔符——太平人寿产品中出现
            elif elementType == 'ItemExplanationSeparator':
                print("Separator Begin")
                flagExplanation = True
            # 如果p是footer:将flagExplanation复原
            elif elementType == 'Footer':
                print("Footer happens")
            # 如果p不是以上各种，那就可能是content
            elif elementType == 'ItemExplanationContent':
                print("ItemExplanationContent happens")
            elif elementType == 'Content_belonged_to_certain_Heading':
                print("Content_belonged_to_certain_Heading happens")
                contentZone.append(element)
            elif elementType == 'Content_Belonged_to_No_Heading':
                print("Content_Belonged_to_No_Heading happens :%s" % element.xpath('descendant::text()'))
                continue
            elif elementType == 'Other':
                print("Other happens")
                continue
            else:
                raise RuntimeWarning("Warning")
        # 返回dataframe
        # 生成heading-content dataframe:df1
        col1 = ['company', 'product', 'heading', 'headingContent']
        df1 = pd.DataFrame(columns=col1)
        # df1.set_index(["index"], inplace=True)
        for heading, headingContent in dicHeadingContent['detail'].items():
            df1 = df1.append(pd.DataFrame([[companyName, productName, heading, headingContent]], columns=col1),
                             ignore_index=True)
        # 生成terminology-content dataframe:df2
        col2 = ['company', 'product', 'term', 'termContent']
        df2 = pd.DataFrame(columns=col2)
        # df2.set_index(["index"], inplace=True)
        for term, termContent in dicTerminology['detail'].items():
            df2 = df2.append(pd.DataFrame([[companyName, productName, term, termContent]], columns=col2),
                             ignore_index=True)
        return df1,df2

    def dataFrame2sql(self, dataFrame, tableName):
        #写入mysql
        engine = create_engine("mysql+pymysql://{user}:{password}@{hostname}:{port}/{schema}?charset={charset}".format\
                                   (user=self.flags.mysql_user, password=self.flags.mysql_password, hostname=self.flags.mysql_hostname,
                                    port=self.flags.mysql_port, schema=self.flags.mysql_schema, charset=self.flags.mysql_charset))
        pd.io.sql.to_sql(dataFrame, tableName, con=engine, index=False, if_exists='replace')

