#coding=utf-8
'''
本模块保存一些特定场景的功能脚本，是一些函数的组合。
不那么通用，所以不保存为函数，而是保存为脚本
'''

import xlrd
import numpy as np
from tool import download_file
import os
import codecs
import re
import pandas as pd
import pickle
from firstStep_RawFormatTransformation import parsePDF2TXT, cleanDirtyCorpus
from tool import getEntityContext, mergeFiles2One
from tool import merge2Dic, getTaggedCorpus, getClauseIdentity
from random import shuffle
from math import ceil, floor
from sklearn.feature_extraction.text import CountVectorizer

########################## SCIRPT 1 ###############################
# 功能：从xls中指定的pdf清单下载文件，保存到指定文件夹
# 参数如下：
# 1.产品清单，为xls文件
path = 'E:/工作/Python/保险产品.xls'
# 2.指定下载的文件清单在哪个sheet中
sheetIndex = 1
# 3.指定从第几行开始下载，默认为0
start = 3201
end = 4697
# 4.指定下载的文件存放在哪个目录下
folder = 'E:/工作/保险语料/除太平人寿外其他公司的寿险产品/'


# 脚本运行
productCompanyIndex = 0
productNameIndex = 1
productDownloadIndex = 9
workbook = xlrd.open_workbook(path)
sheetTraining = workbook.sheets()[sheetIndex]
rowNum = sheetTraining.nrows
colNum = sheetTraining.ncols
for i in np.arange(start, end):
    if i != 0:
        # 获取文件参数
        productName = '#' + str(i) + sheetTraining.cell_value(i, productNameIndex) + '@' + sheetTraining.cell_value(i, productCompanyIndex)
        productLink = sheetTraining.cell_value(i, productDownloadIndex)
        # 下载文件
        download_file(productLink, productName, folder)
        print("File#%d OK! %f%% completed!" % (i, (i*100.0)/rowNum) )


########################## SCIRPT 2 ###############################
# 功能：将指定文件夹下的多个pdf转换为对应的txt
# 参数如下：
# 1.pdf文件夹
pdfFolder = 'E:/工作/保险语料/除太平人寿外其他公司的寿险产品/'
# 2.转换结果txt文件夹
txtFolder = 'E:/工作/保险语料/除太平人寿外其他公司的寿险产品/txt/'

# 脚本运行
parsePDF2TXT(pdfFolder, txtFolder)


########################## SCIRPT 3 ###############################
# 功能：找到entity的context，存入字典
# 参数如下：
# 1.要转化的txt文件列表与对应的label列表、优先级列表：[(file1, label1, priority1),(file2, label2, priority2),...(fileN, labelN,priorityN)]
#   “优先级”代表当一个词语在多个表中出现时，选择哪个label。优先级：0~9，值越小，优先级越高
fileFolder = 'E:/工作/保险语料/参数归纳'
fileList = [(os.path.join(fileFolder, '单个命名实体.txt'), 'ENTITY', 2),
            (os.path.join(fileFolder, '属性.txt'), 'ATTRIBUTE', 3),
            (os.path.join(fileFolder, '事件.txt'), 'EVENT', 1)]
# 2.保存的csv路径+文件名
destCSV = os.path.join(fileFolder, '综合的实体.csv')
# 3.保存的dump路径+文件名
destDump = os.path.join(fileFolder, '综合的实体.pkl')
destTxt = os.path.join(fileFolder, '实体列表.txt')
# 4.语料文件夹
corpusFolder = 'E:/工作/保险语料/除太平人寿外其他公司的寿险产品/temp/'
# 5.标记实体后的语料储存文件夹
markedCorpusFolder = 'E:/工作/保险语料/除太平人寿外其他公司的寿险产品/markedtxt/'

# 脚本运行
# step1:整理多张表，加入nameLength项 & step2:多张表合成一张
fileList = sorted(fileList, key=lambda x:x[-1], reverse=False)
itemList = {}
for x in fileList:
    fileName = x[0]
    fileLabel = x[1]
    filePriority = x[-1]
    with codecs.open(fileName, 'rb', encoding='gb18030') as file:
        for line in file.readlines():
            line = line.split()
            if len(line) != 1:
                break
            item = line[0]
            if item not in itemList:# 如果有更高优先级的相同词语在字典中，则已高优先级为主
                nameLength = len(item)
                itemList[item] = {'nameLength':nameLength, 'Label':fileLabel}

# step3:在语料中找出上下文，保留下来
corpusList = os.listdir(corpusFolder)
entityList = [x[0] for x in sorted(itemList.items(), key=lambda item:item[1]['nameLength'], reverse=True)]
with codecs.open(destTxt, 'wb', encoding='gb18030') as file:
    file.write('\r\n'.join(entityList))
for oneCorpus in corpusList:
    context = getEntityContext(os.path.join(corpusFolder, oneCorpus), markedCorpusFolder, entityList)
    merge2Dic(itemList, context)

# step4:保存
with codecs.open(destDump, 'wb') as file:
    pickle.dump(itemList, file)

df = pd.DataFrame.from_dict(itemList, orient='index')
df.to_csv(destCSV, encoding='utf-8')

########################## SCIRPT 4 ###############################
# 功能：将txt的格式整理，存入csv
# 参数如下：
path = 'E:/工作/保险语料/陆-公司无关名词归纳.txt'
dest = 'E:/工作/保险语料/陆-公司无关名词归纳.csv'
totalList = []
with codecs.open(path, "rb", encoding='utf-8') as file:
    allLines = file.readlines()
    for line in allLines:
        # 格式处理
        line = re.sub(r'[A-Z:：]', '', line)
        lineList = line.split()
        if len(lineList)!= 0:
            totalList.extend(lineList)

name = ['entity']
test = pd.DataFrame(columns=name, data=totalList)
test.to_csv(dest, encoding='utf-8')


########################## SCIRPT 5 ###############################
# 测试OK
# 功能：在corpus中根据entityList标记出每个字的B/I/E/S/O标签
fileFolder = 'E:/工作/保险语料/参数归纳'
    # 标记实体后的语料储存文件夹
markedCorpusFolder = 'E:/工作/保险语料/除太平人寿外其他公司的寿险产品/temp/markedtxt'
# 1.保存的dump路径+文件名（实体列表由“脚本：记录context”的中间过程产生）
destDump = os.path.join(fileFolder, '实体列表.pkl')
destTxt = os.path.join(fileFolder, '实体列表.txt')
    # 语料文件夹
corpusFolder = 'E:/工作/保险语料/除太平人寿外其他公司的寿险产品/txt/'
# 2.读入实体
entityFile = codecs.open(destTxt, 'rb', encoding='gb18030')
entityList = entityFile.read().split('\r\n')
entityFile.close()
# 3.每个corpus文件产生对应的字label文件
corpusList = os.listdir(corpusFolder)
for oneCorpus in corpusList:
    getTaggedCorpus(os.path.join(corpusFolder, oneCorpus), os.path.join(markedCorpusFolder, oneCorpus), entityList)


########################## SCIRPT 6 ###############################
# 测试OK
# 功能：将多个txt文件合成两个，一个用于train_data，一个用于test_data（注意两个文件的分隔处要直接连上，既不要额外空行，也不要直接连接）
# 1.各文件夹
markedCorpusFolder = 'E:/工作/保险语料/除太平人寿外其他公司的寿险产品/temp/markedtxt'

mergeFolder = 'E:/工作/保险语料/除太平人寿外其他公司的寿险产品/temp/mergeMarkedtxt'
mergedTrainFile = os.path.join(mergeFolder, 'mergedTrainFile.txt')
mergedTestFile = os.path.join(mergeFolder, 'mergedTestFile.txt')
# 2.训练集和验证集的比例
trainPercent = 0.7
validationPercent = 0.3
shuffled = True
# 3.开始合并
markedFileList = [os.path.join(markedCorpusFolder, x) for x in os.listdir(markedCorpusFolder)]
numMarkedFile = len(markedFileList)
# 训练数据的文件数目
numTrainFile = floor(numMarkedFile*trainPercent) if floor(numMarkedFile*trainPercent)!=numMarkedFile else (numMarkedFile-1)
shuffle(markedFileList)
# 合并train_data
mergeFiles2One(markedFileList[0:numTrainFile], mergedTrainFile)
# 合并test_data
mergeFiles2One(markedFileList[numTrainFile: -1], mergedTestFile)

########################## SCIRPT 7 ###############################
# 测试OK
# 功能：将给定目录下的所有文件进行清洗，结果存入另一个目录
rawFileFolder = 'E:/我的资料/2017-18工作/保险语料/train除太平人寿外其他公司的寿险产品/txt'
cleanFileFolder = 'E:/我的资料/2017-18工作/保险语料/train除太平人寿外其他公司的寿险产品/cleanTXT'

fileList = os.listdir(rawFileFolder)
for file in fileList:
    cleanDirtyCorpus(os.path.join(rawFileFolder, file), os.path.join(cleanFileFolder, file))


########################## SCIRPT 8 ###############################
# 测试不OK，因为pdf转化来的docx的xml中的格式很不稳定
# 功能：将给定xml解析为两个字典，分别为：{标题-内容}、{名词-定义}
path = 'E:/工作/保险语料/太平人寿的寿险产品/word/太平安心无忧两全保险@太平人寿保险有限公司/word/document.xml'
dicHeadingContent, dicTerminology = getEntityAndRelationFromXML(path)

# 解析完xml，生成实体列表和关系列表
headingEventPath = 'E:\\工作\\保险语料\\太平人寿的寿险产品\\event\\headingEvent.csv'
terminologyEntityPath = 'E:\\工作\\保险语料\\太平人寿的寿险产品\\entity\\properNoun.csv'
terminolotyContentPath = 'E:\\工作\\保险语料\\太平人寿的寿险产品\\relation\\Noun-terminology.csv'
headingContentPath = 'E:\\工作\\保险语料\\太平人寿的寿险产品\\relation\\heading-content.csv'
# 保存词典
knowledgeGraphPath = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿的寿险产品\\KnowledgeGraph\\'
writeDic2CSV(dicHeadingContent, os.path.join(knowledgeGraphPath, 'heading-content.csv'), option='key-relation-value', relation='内容为')
writeDic2CSV(dicTerminology, os.path.join(knowledgeGraphPath, 'Noun-terminology.csv'), option='key-relation-value', relation='定义为')
with open(os.path.join(knowledgeGraphPath, 'heading-content.dump'), 'wb') as file:
    pickle.dump(dicHeadingContent, file)
with open(os.path.join(knowledgeGraphPath, 'Noun-terminology.dump'), 'wb') as file:
    pickle.dump(dicTerminology, file)


########################## SCIRPT 9 ###############################
# 将目录下的所有pdf转化为docx——》zip解压
folder = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\docx\\'
xmlFolder = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\xml\\'
fileList = os.listdir(folder)
# pdf转docx：现在是使用lightPDF工具

# docx改名为zip
for filename in fileList:
    portion = os.path.splitext(filename)#分离文件名字和后缀
    print(portion)

    if portion[1] ==".docx":#根据后缀来修改,如无后缀则空
        oldname = portion[0]+".docx"
        newname = portion[0]+".zip"    #要改的新后缀
        os.chdir(folder)#切换文件路径,如无路径则要新建或者路径同上,做好备份
        os.rename(filename,newname)
# docx用zip解压为文件夹
zipList = [re.sub(r'(.docx)', '.zip', name) for name in fileList]
for zipFile in zipList:
    name = os.path.splitext(zipFile)
    if name[1] == '.zip':
        file_zip = zipfile.ZipFile(os.path.join(folder, zipFile), 'r')
        tempFolder = os.path.join(xmlFolder, 'temp')
        file_zip.extract('word/document.xml', path=tempFolder)
        shutil.move(os.path.join(tempFolder, 'word/document.xml'),\
                    xmlFolder+name[0]+'.xml')
# 删除临时文件夹
shutil.rmtree(tempFolder)

# zip改名回docx
for filename in fileList:
    portion = os.path.splitext(filename)#分离文件名字和后缀
    print(portion)

    if portion[1] ==".zip":#根据后缀来修改,如无后缀则空
        oldname = portion[0]+".zip"
        newname = portion[0]+".docx"    #要改的新后缀
        os.chdir(folder)#切换文件路径,如无路径则要新建或者路径同上,做好备份
        os.rename(filename,newname)


########################## SCIRPT 9 ###############################
# 功能：从xml提取出dicHeadingContent（标题，内容），dicTerminology（术语，定义）两个词典，并写入Neo4j
# 1、将xml解析为树结构，并得到该树的根。
XMLPath = 'E:/工作/保险语料/太平人寿的寿险产品/word/太平安心无忧两全保险@太平人寿保险有限公司/word/document.xml'
# tree = etree.parse(path)#将xml解析为树结构
# root = tree.getroot()#获得该树的树根

if __name__ == '__main__':
    parser = etree.XMLParser()
    root = etree.parse(XMLPath, parser).getroot()
    dicHeadingContent = {}  # 标题和对应的内容存储在里面
    dicTerminology = {}  # 专有名词和对应的解释存储在里面
    # 获取公司名和产品名
    companyName, productName = getClauseIdentity(XMLPath)
    dicHeadingContent = {'company':companyName, 'product':productName, 'detail':{}}
    dicTerminology = {'company': companyName, 'product': productName, 'detail':{}}

    # 0.找出所有p节点，作为我们处理的全集
    pList = root.xpath('descendant::w:p', namespaces=root.nsmap)
    terminationList = []
    headingContentList = []
    flagHeading = False
    flagExplanation = False
    # PART1:把p放到对应的区域中
    # 1.定位正文区域的开头：第一个heading1处
    # 2.将正文区域的所有p节点分为2部分：名词定义区域 和 其他区域
    # 名词定义区域：定义分隔符开始的p——紧接着的第一个footer的p
    # 其他区域：包含了子标题和对应的内容
    pLen = len(pList)
    flagContentBegin = False
    for pNode in pList:
        nodeType = getNodeType(pNode, flagHeading, flagExplanation)
        if flagContentBegin == True:
            # content范围内，分隔符和footer之间的是“terminology”，其他都是“headingContent”
            # 如果p是名词解释分隔符——太平人寿产品中出现
            if nodeType == 'ItemExplanationSeparator':
                print("Separator Begin")
                flagExplanation = True
            # 如果p是footer:将flagExplanation复原
            elif nodeType == 'Footer':
                print("Footer happens")
                flagExplanation = False
            elif nodeType == 'ItemExplanationContent':
                print("ItemExplanationContent happens")
                terminationList.append(pNode)
            else:
                print("HeadingContent happens")
                headingContentList.append(pNode)
        else:
            # 第一个Heading1之前的都是目录
            if len(pNode.xpath('descendant::w:pStyle[contains(@w:val,"Heading1")]', namespaces=pNode.nsmap)):
                flagContentBegin = True
                flagHeading = True
                headingContentList.append(pNode)
            else:
                continue

    # PART2:提取各区域的内容
    # 3.从名词定义区域提取内容，存入dicTerminology
    ''''''
    content1 = []
    for pNode in terminationList:
        content1.extend(pNode.xpath('descendant::text()'))
    content = '。' + ''.join(content1)
    content = re.sub('(）)([0-9]{1,})', lambda x: x.group(1) + '。' + x.group(2),
                     content)  # 在所有“右括号+数字”模板如“）9”的右括号后插入一个中文句号
    content = re.split('。[0-9]{1,}', content)

    for item in content:
        if len(item) == 0:
            continue
        else:
            # 替换第一个冒号为名词与定义的分隔符
            temp = re.sub('：', '||', item, count=1)
            key, value = temp.split('||')
            dicTerminology['detail'][key] = value

    # 4.从其他区域抽取内容，存入dicHeadingContent。
    #  处理的是List。要把这个list尽量控制的简单，只有heading和content
    flagExplanation = False
    flagHeading = False
    heading = ''
    lastHeading = ''
    contentZone = []
    explanationZone = []
    for element in headingContentList:
        # 判断当前p是什么类型
        elementType = getNodeType(element, flagHeading, flagExplanation)
        # 如果p是heading
        if elementType == 'Heading':
            print("Headings Begin")
            flagHeading = True
            lastHeading = copy.copy(heading)
            heading = ''.join(element.xpath('descendant::text()'))
            heading = re.sub('\s', '', heading)  # 将所有的空白字符删除
            print("%s" % heading)
            result = re.search('第.{1,}条([\u4e00-\u9fa5]+[\S]{0,})', heading)
            heading = result.group(1) if result != None else heading

            if len(lastHeading) != 0:
                # 遇到新heading，将内容联系到上一个heading
                dicHeadingContent['detail'][lastHeading] = getZoneContent(contentZone)
                contentZone = []
        # 如果p是名词解释分隔符——太平人寿产品中出现
        elif elementType == 'ItemExplanationSeparator':
            print("Separator Begin")
            flagExplanation = True
        # 如果p是footer:将flagExplanation复原
        elif elementType == 'Footer':
            print("Footer happens")
        # 如果p不是以上各种，那就可能是content
        elif elementType == 'ItemExplanationContent':
            print("ItemExplanationContent happens")
        elif elementType == 'Content_belonged_to_certain_Heading':
            print("Content_belonged_to_certain_Heading happens")
            contentZone.append(element)
        elif elementType == 'Content_Belonged_to_No_Heading':
            print("Content_Belonged_to_No_Heading happens :%s" % element.xpath('descendant::text()'))
            continue
        elif elementType == 'Other':
            print("Other happens")
            continue
        else:
            raise RuntimeWarning("Warning")

    # 5.将dic中的数据直接写入Neo4j
    insuranceGraph = Graph(
        "http://localhost:7474",
        username="neo4j",
        password="tongxin2007"
    )
    # 是否存在公司节点
    productName, companyName = XMLPath.split('/')[-3].split('@')
    productNode = Node()
    matcher = NodeMatcher(insuranceGraph)
    matchResult = matcher.match("Product", name=productName)
    if matchResult.first() != None:
        productNode = matchResult.first()
    else:
        productNode = Node("Product", name=productName)
    # 标题事件
    for key, value in dicHeadingContent['detail'].items():
        node = matcher.match("heading", name=key, value=value).first()
        if node == None:
            node = Node("heading", name=key, value=value)
        insuranceGraph.create(node)  # 实体节点
        productHeadingRelation = Relationship(productNode, '包含', node)  # 关系
        insuranceGraph.create(productHeadingRelation)
    # 专有名词
    for key, value in dicTerminology['detail'].items():
        node = matcher.match("properNoun", name=key, value=value).first()
        if node == None:
            node = Node("properNoun", name=key, value=value)
        insuranceGraph.create(node)  # 实体节点
        productTerminologyRelation = Relationship(productNode, '包含', node)  # 关系
        insuranceGraph.create(productTerminologyRelation)


########################## SCIRPT 9 ###############################
# 提取出所有产品的“投保范围”：产品名 公司名 投保范围文本
givenHeading = '保险责任'
content = [['产品名', '公司名', heading]]
folder = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\xml'
summaryFolder = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\summary'
# 解析xml，从中取出产品名+公司名+指定标题的内容
xmlFileList = os.listdir(folder)
parser = etree.XMLParser()
for xmlFile in xmlFileList:
    # 取出公司名
    name = os.path.splitext(xmlFile)
    productName, companyName = name[0].split('@')
    productName = re.sub(r'#[0-9]+', '', productName)
    # 解析xml
    root = etree.parse(XMLPath, parser).getroot()
    headingContent = getHeadingContent(xmlFile, givenHeading)
    # 内容保存
    ContentThisRound = [productName, companyName, headingContent]
    content.append(ContentThisRound)
# 所有产品的指定heading下内容一次性写入
csvName = os.path.join(summaryFolder, heading + '.csv')
with open(csvName, 'a', encoding='utf-8', newline='') as file:
    csv_writer = csv.writer(file, dialect='excel')
    csv_writer.writerows(content)



########################## SCIRPT 10 ###############################
# 功能：pyLTP的调试，不一定有用
content = '我们在收到保险金给付申请书及合同约定的证明和资料后，将在 5 个工作日内作出核定；情形复杂的，\
在 30 日内作出核定。对属于保险责任的，我们在与受益人达成给付保险金的协议后 10 日内，履行给付保险\
金义务。'
# 0.预处理
LTP_DATA_DIR = 'C:/Users/temp/AppData/Local/Programs/Python/Python36/Lib/site-packages/pyltp-master/ltp_data_v3.4.0/'  # ltp模型目录的路径
lexionPath = 'C:/Users/temp/AppData/Local/Programs/Python/Python36/Lib/site-packages/pyltp-master/lexicon'
cws_model_path = os.path.join(LTP_DATA_DIR, 'cws.model')  # 分词模型路径，模型名称为`cws.model`
pos_model_path = os.path.join(LTP_DATA_DIR, 'pos.model')  # 词性标注模型路径，模型名称为`pos.model`
par_model_path = os.path.join(LTP_DATA_DIR, 'parser.model')  # 依存句法分析模型路径，模型名称为`parser.model`


# 1.将条款转化为标题-内容的字典
jieba.load_userdict('C:\\Users\\temp\\AppData\\Local\\Programs\\Python\\Python36\\Lib\\site-packages\jieba\\insuranceDict.txt')
result = jieba.cut(content)

# 2.对于每个标题的内容，从中识别出标题涉及到的名词。
# 存入词典dicHeadingElements {heading:([relatedNouns], [relatedEvents])}
# for heading, content in dicHeadingContent.items():
segmentor = Segmentor()  # 初始化实例
segmentor.load_with_lexicon(cws_model_path, lexionPath)  # 加载模型
words = segmentor.segment(content)  # 分词

postagger = Postagger() # 初始化实例
postagger.load_with_lexicon(pos_model_path, lexionPath)  # 加载模型
postags = postagger.postag(['我们','在','收到','保险金','给付','申请书','后'])  # 词性标注

parser = Parser() # 初始化实例
parser.load(par_model_path)  # 加载模型
arcs = parser.parse(words, postags)  # 句法分析

print('\t'.join(words))
print('\t'.join(postags))
print("\t".join("%d:%s" % (arc.head, arc.relation) for arc in arcs))
segmentor.release()  # 释放模型
postagger.release()
parser.release()  # 释放模型

# 3.对于每个标题的内容，从中识别出标题涉及到的事件

# 4.识别事件间的关系：主要是“条件——结果”和“属性——属性值”两类关系

# 5.做完以上工作，就可以设计算法比较子标题对应的关键保险事件了

########################## SCIRPT 11 ###############################
# 功能：根据语料统计ngram频数，频繁的写入字典
# 1.将文件夹下所有长句按照标点符号分割成分句
# 2.统计n-gram出现次数
# 3.把频数大于threshold的n-gram写入指定文件

cleanFileFolder = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/cleanTXT'
fileList = os.listdir(cleanFileFolder)
threshold = ceil(len(fileList)*0.5)
specialDictpath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/insurDict'+str(threshold)+'.txt'

shortSentence = []
symbol = r'[,.?!;，。？！；]'
# 1
for one in fileList:
    with codecs.open(os.path.join(cleanFileFolder, one), 'r', encoding='utf-8') as file:
        content = file.read()
        content = re.sub(symbol, '\r\n', content)
        content = re.split(r'[\r\n]+', content)
        shortSentence.extend(content)

# 2
vectorizer = CountVectorizer(input='content',\
                             encoding='utf-8', \
                             ngram_range=(2,5),\
                             analyzer='char')
shortSentence = ''.join(shortSentence)
# 清除一些不需要的内容，减少统计量
shortSentence = re.sub(r'第[\S]{1,3}条', '', shortSentence)
X = vectorizer.fit_transform([shortSentence])

# 3
qualifiedIndex = (X>threshold).indices
writeContent = []
ngramList = vectorizer.get_feature_names()
for index in qualifiedIndex:
    writeContent.append((ngramList[index], X[(0,index)]))
writeContent = sorted(writeContent, key=lambda x:x[1], reverse=True)
with codecs.open(specialDictpath, 'wb', encoding='utf-8') as file:
    for item in writeContent:
        file.write("%s\t%d\r\n" % (item[0], item[1]))

########################## SCIRPT 12 ###############################
# 测试OK
# 功能：人工筛选词典，问答形式
# 使用感受：容易发困，然后出错。
#         出错了无法修改；
#         不能随时开始随时停止，必须做完才能写入
# 结论：找个好用点的编辑器，手动修改比较好
srcPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/insurDict362.txt'
destpath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/checkedDic/insurDict362_ManualCheck.txt'
content = []
writeContent = []
with codecs.open(srcPath, 'rb', encoding='utf-8') as srcfile:
    content = srcfile.readlines()

print("type 'Y' for save, everything else for skip")
for item in content:
    userAnswer = input(item)
    if userAnswer == 'Y' or userAnswer == 'y':
        writeContent.append(item)
    else:
        continue
with codecs.open(destpath, 'wb', encoding='utf-8') as descfile:
    descfile.writelines(writeContent)



########################## SCIRPT 13 ###############################
# 测试OK
#扫描jieba词典，筛选出频次大于门限threshold的词，并排序保存
jiebaDicPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/jiebaDict.txt'
filteredDicPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/checkedDic/jiebaDict_Filtered.txt'
srcContent = []
destContent = []
threshold = 0.7 # 频次从大到小排序，仅保留前百分之70分位数

with codecs.open(jiebaDicPath, 'rb', encoding='utf-8') as srcFile:
    srcContent = srcFile.readlines()
itemNum = len(srcContent)

temp = sorted(srcContent, key=lambda x:eval(x.split()[1]), reverse=True)
thresholdFreq = eval(srcContent[floor(itemNum*threshold)].split()[1])
for item in temp:
    freq = eval(item.split()[1])
    if freq >= thresholdFreq:
        destContent.append(item)
    else:
        break

with codecs.open(filteredDicPath, 'wb', encoding='utf-8') as destFile:
    destFile.writelines(destContent)

########################## SCIRPT 14 ###############################
# 功能：新词典未进行词性标注时，与jieba词典对齐，找到对应词性
# 复杂度：专业词典长度*jieba词典长度
jiebaDicPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/jiebaDict.txt'
newDicPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/checkedDic/insurDict362_ManualCheck.txt'
WORDPOS = 0
FREQPOS = 1
POLARITYPOS = 2
srcContent = []
destContent = []
jiebaDic = {}

with codecs.open(jiebaDicPath, 'rb', encoding='utf-8') as srcFile:
    srcContent = srcFile.readlines()

# 把jieba建立为字典
for item in srcContent:
    if len(item.strip()) == 0:
        continue
    else:
        word, freq, polarity = item.split()
        jiebaDic[word] = polarity

# 查询
with codecs.open(newDicPath, 'rb', encoding='utf-8') as newDicFile:
    newDicContent = newDicFile.readlines()
for item in newDicContent:
    if len(item.strip()) == 0:
        continue
    else:
        word, freq = item.split()
        if word in jiebaDic:
            destContent.append('\t'.join([word, freq, jiebaDic[word]])+'\r\n')
        else:
            destContent.append(item)
with codecs.open(newDicPath, 'wb', encoding='utf-8') as newDicFile:
    newDicFile.writelines(destContent)



########################## SCIRPT 15 ###############################
# 功能：根据词性、频数对已有jieba词典进行裁剪
jiebaDicPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/jiebaDict.txt'
newDicPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/checkedDic/jiebaDict_Tailored.txt'
debugPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/checkedDic/jiebaDict_TailoredDebug.log'
WORDPOS = 0
FREQPOS = 1
POLARITYPOS = 2
srcContent = []
destContent = []
polarityDeleteSet = set(['n', 'm', 'e', 'y', 'o', 'x'])
thresholdFreq = 30

with codecs.open(jiebaDicPath, 'rb', encoding='utf-8') as srcFile:
    srcContent = srcFile.readlines()

for item in srcContent:
    if len(item.strip()) == 0:
        continue
    else:
        word, freq, polarity = item.split()
        polarityLegal = polarity[0] not in polarityDeleteSet
        freqLegal = eval(freq) >= thresholdFreq
        if polarityLegal and freqLegal:
            destContent.append(item)
destContent = sorted(destContent, key=lambda x:eval(x.split()[1]), reverse=True)

with codecs.open(newDicPath, 'wb', encoding='utf-8') as destFile:
    destFile.writelines(destContent)
with codecs.open(debugPath, 'wb', encoding='utf-8') as logFile:
    tailorInfor = '''source dictionary is {a}\r\n
tailored dictionay is {b}\r\n
deleted polarity set is {c}\r\n
threshold frequency is {d}\r\n     
                '''.format(a=jiebaDicPath, b=newDicPath, c=polarityDeleteSet, d=thresholdFreq)
    logFile.write(tailorInfor)


########################## SCIRPT 16 ###############################
# 功能：向通用词典（大）中合并专业词典（小），重复词频数以专业词典为准
# 通用词典需要按照频数由大到小排列
jiebaDicPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/checkedDic/jiebaDict_Tailored.txt'
specialDicPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/checkedDic/insurDict362_ManualCheck.txt'
newDicPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/checkedDic/finalDict.txt'
srcContent = []
specialDicContent = []
destContent = []
finalDic = {}
# 通用词典统计：有哪些key、最大频数是多少
with codecs.open(jiebaDicPath, 'rb', encoding='utf-8') as srcFile:
    srcContent = srcFile.readlines()
freqAddition = eval(srcContent[0].split()[1])   #专业词典通过提高频数，达到优先级比通用词典高的效果
for item in srcContent:
    if len(item.strip()) == 0:
        continue
    else:
        word, freq, polarity = item.split()
        finalDic[word] = (freq, polarity)
# 专业词典写入
with codecs.open(specialDicPath, 'rb', encoding='utf-8') as specialDicFile:
    specialDicContent = specialDicFile.readlines()
for item in specialDicContent:
    if len(item.strip()) == 0:
        continue
    else:
        word, freq, polarity = item.split()
        finalDic[word] = (eval(freq)+freqAddition, polarity)
# 字典内容保存
for key, value in finalDic.items():
    destContent.append('{a}\t{b}\t{c}\r\n'.format(a=key, b=value[0], c=value[1]))
with codecs.open(newDicPath, 'wb', encoding='utf-8') as destFile:
    destFile.writelines(destContent)

########################## SCIRPT 17 ###############################
# 测试LTP的句法分析
destDicPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/checkedDic/finalDict_LTPtag.txt'
LTP_DATA_DIR='C:\\Users\\temp\\AppData\\Local\\Programs\\Python\\Python36\\Lib\\site-packages\\pyltp-master\\ltp_data_v3.4.0\\'  # ltp模型目录的路径
par_model_path = os.path.join(LTP_DATA_DIR, 'parser.model')  # 依存句法分析模型路径，模型名称为`parser.model`
srl_model_path = os.path.join(LTP_DATA_DIR, 'pisrl_win.model')  # 语义角色标注模型目录路径，模型目录为`srl`。注意该模型路径是一个目录，而不是一个文件。

# 分词+词性标注
jieba.load_userdict(destDicPath)
result = posseg.cut(content)
words = []
postags = []
for word, flag in result:
    words.append(word)
    postags.append(flag)

# 句法分析
parser = Parser() # 初始化实例
parser.load(par_model_path)  # 加载模型

# words = ['元芳', '你', '怎么', '看']
# postags = ['nh', 'r', 'r', 'v']
arcs = parser.parse(words, postags)  # 句法分析
arcList = [x for x in arcs]

print("\t".join("%d:%s(%s)" % (pair[0].head, pair[0].relation, pair[1]) for pair in zip(arcList, words)))
parser.release()  # 释放模型
#语义角色
labeller = SementicRoleLabeller() # 初始化实例
labeller.load(srl_model_path)  # 加载模型
roles = labeller.label(words, postags, arcs)  # 语义角色标注

for role in roles:
    print(role.index, "".join(
        ["%s:(%d,%d)" % (arg.name, arg.range.start, arg.range.end) for arg in role.arguments]))
labeller.release()  # 释放模

########################## SCIRPT 18 ###############################
# 功能：把key-value的字典（如heading-content字典）中的内容做词法、句法分析后存入新字典
destDicPath = 'E:/工作记录/保险行业语料/保险合同/保险数据/太平人寿的寿险产品/dic/checkedDic/finalDict_LTPtag.txt'
LTP_DATA_DIR='C:\\Users\\temp\\AppData\\Local\\Programs\\Python\\Python36\\Lib\\site-packages\\pyltp-master\\ltp_data_v3.4.0\\'  # ltp模型目录的路径
par_model_path = os.path.join(LTP_DATA_DIR, 'parser.model')  # 依存句法分析模型路径，模型名称为`parser.model`
srl_model_path = os.path.join(LTP_DATA_DIR, 'pisrl_win.model')  # 语义角色标注模型目录路径，模型目录为`srl`。注意该模型路径是一个目录，而不是一个文件。
knowledgeGraphPath = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿的寿险产品\\KnowledgeGraph\\太平福禄康瑞2018终身重大疾病保险条款@太平人寿保险有限公司'
titleContentDicPath = os.path.join(knowledgeGraphPath, 'heading-content.dump')
newDicPath = os.path.join(knowledgeGraphPath, 'heading-content-analyzed.dump')
analyzeKeyContent(titleContentDicPath, newDicPath, destDicPath, par_model_path, srl_model_path)



########################## SCIRPT 19 ###############################
path = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿的寿险产品\\KnowledgeGraph\\太平福禄康瑞2018终身重大疾病保险条款@太平人寿保险有限公司'
ConLLPath = os.path.join(path, 'DP.conll')
file = open(os.path.join(path, 'heading-content-analyzed.dump'), 'rb')
sourceDic = pickle.load(file)
entityCSV = os.path.join(path, 'entity.csv')

entityContent = []
company = sourceDic['company']
product = sourceDic['product']
for key, value in sourceDic['detail'].items():
    heading = key
    words = value['words']
    postags = value['postags']
    arcList = value['arcList']
    roles = value['roles']
    numSentence = len(words)
    for i in np.arange(numSentence):
        # 把words中的空白字符换成‘LU’，否则dependencyViewer无法识别空白字符
        convertLTPresult2ConLL([re.sub(r'\s','LU',x) for x in words[i]], postags[i], arcList[i], ConLLPath)
        # 提取实体
        # 策略1：将所有名词作为实体
        for x in zip(words[i], postags[i]):
            # 名词判断
            if 'n' in x[1]:
                entityContent.append([company, product, key, x[0]])

        # 提取实体之间的关系
        hello=1

        # 提取事件

# 写入CSV
with open(entityCSV, 'a', newline='', encoding='utf-8') as file:
    csv_writer = csv.writer(file, dialect='excel')
    csv_writer.writerows(entityContent)

########################## SCIRPT 20 ###############################
xlsxPath = 'E:\\工作记录\\知识图谱\\知识库\\实例与概念的对应关系\\地理位置实例与地理位置概念-对应关系.xlsx'
csvPath = 'E:\\工作记录\\知识图谱\\知识库\\实例与概念的对应关系\\地理位置实例与地理位置概念-对应关系.csv'
xlsx2csv(xlsxPath, csvPath)

########################## SCIRPT 21 ###############################
# 功能：构造训练数据
path = 'E:\\工作记录\\保险行业语料\\问答库\\knowledge_question.csv'
formattedPath = 'E:\\工作记录\\保险行业语料\\问答库\\question_class_subclass.csv'

content = [['Question', 'Class', 'subClass']]
with open(path, 'r', newline='', encoding='utf-8') as csvFile:
    reader = csv.DictReader(csvFile, dialect='excel')
    for row in reader:
        question = re.sub(r'[\s]+', '', row['question'])    #有些Q中有\n，需要去除
        subClass = eval(row['id']) if eval(row['pid']) == 0 else eval(row['pid'])
        content.append([question, row['category_id'], subClass])
with open(formattedPath, 'w', newline='', encoding='utf-8') as file:
    csv_writer = csv.writer(file, dialect='excel')
    csv_writer.writerows(content)

########################## SCIRPT 22 ###############################
# 功能：根据模板抽取信息
patternPath = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\summary\\投保范围-pattern.csv'
PyRegPath = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\summary\\投保范围-PyRegExp.csv'
csvPath = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\summary\\投保范围.csv'
finalCSVPath = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\summary\\投保范围-result.csv'
manualPattern2PythonRegularExpression(patternPath, PyRegPath)

content = []
content.append(['ProductName', 'CompanyName', 'Content', 'START', 'END'])
patternFile = open(PyRegPath, 'r', encoding='utf-8')
patternReader = csv.reader(patternFile, dialect='excel')
patternList = [line for line in patternReader]
originalFile = open(csvPath, 'r', newline='', encoding='utf-8')
originalFileReader = csv.reader(originalFile, dialect='excel')
content = []
content.append(['ProductName', 'CompanyName', 'content', 'START', 'END', 'OtherConstraint'])
for row in originalFileReader:
    for patternRecord in patternList:
        if len(patternRecord)!=0:
            reg = re.compile(patternRecord[-1])
            result = reg.match(row[-1])
            if result is not None:
                result = result.groupdict()
            else:
                continue
            if len(result)!=0:
                content.append([row[0], row[1], row[2], result['START'], result['END']])
# 移除中间文件
patternFile.close()
originalFile.close()
os.remove(PyRegPath)

with open(finalCSVPath, 'w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file, dialect='excel')
    writer.writerows(content)


########################## SCIRPT 23 ###############################
# 功能1：将同义词林转换为以word为索引的字典：{'word':heading}，一个词可能有多个heading
# 算法：将所有“=”的记作同义词
cilinPath = 'D:\\User\\Documents\\PycharmProjects\\KG\\rawData\\哈工大社会计算与信息检索研究中心同义词词林扩展版.txt'
transformedCilinPath = 'D:\\User\\Documents\\PycharmProjects\\KG\\rawData\\哈工大社会计算与信息检索研究中心同义词词林扩展版-以词为索引.txt'
transformedCilinPickle = 'D:\\User\\Documents\\PycharmProjects\\KG\\rawData\\哈工大社会计算与信息检索研究中心同义词词林扩展版-以词为索引.dump'


ciliFile = open(cilinPath, 'r', encoding='utf-8')
transformedCilinFile = open(transformedCilinPath, 'w', encoding='utf-8')
dumpFile = open(transformedCilinPickle, 'wb')
content = ['word heading\r\n']
contentDic = {}

# 生成转换后的词典
for line in ciliFile.readlines():
    token = line.split()
    heading = token[0]
    wordList = token[1:]
    for word in wordList:
        if word in contentDic:
            contentDic[word].append(heading)
        else:
            contentDic[word] = [heading]
pickle.dump(contentDic, dumpFile, 0)
# 生成txt
for key, value in contentDic.items():
    content.append(key + ' ' + ' '.join(value) + '\r\n')
transformedCilinFile.writelines(content)


########################## SCIRPT 24 ###############################
# 功能1：测试一个算法检测同义词的Precision和Recall

# 读入同义词林转换词典
transformedCilinPickle = 'D:\\User\\Documents\\PycharmProjects\\KG\\rawData\\哈工大社会计算与信息检索研究中心同义词词林扩展版-以词为索引.dump'
dump = open(transformedCilinPickle, 'rb')
dic = pickle.load(dump)
# 输入一个词
word = '稚童'
# 输入同义词的候选集，并应用词林的转换词典将中间的同义词选出来
candidate = '孩子家 小儿 小人儿 雏儿 幼儿 娃儿 娃娃 娃子 小子 小小子 竖子 孺子 稚子 童蒙 幼 童 孩 小 孺 囡 小朋友 小不点儿 少年儿童 婴儿 婴孩 婴 新生儿 产儿 赤子 乳儿 毛毛 小儿 早产儿 婴幼儿 成年人 壮年人 大人 人 丁 壮丁 佬 中年人 男人 男子 男子汉 男儿 汉子 汉 士 丈夫 官人 男人家 光身汉 须眉 壮汉 男士'
candidate = candidate.split()
y_true = [1 if dic[x] == dic[word] else 0 for x in candidate]
# 调用函数，将认为的同义词都检测出来
predict = [x for x in candidate if wordSimilarity(word, x)]
# 计算precision和recall
result = precision_recall_fscore_support(y_true, predict)
print(result)


########################## SCIRPT 25 ###############################
# 功能：从BERT中取出常用汉字的字向量
# 前置条件：先按照https://blog.csdn.net/zhylhy520/article/details/87615772开启BERT服务
# 未测试

hanziPath = 'E:\\工作记录\\BERT\\hanzi.txt'
characterEmbeddingPath = 'E:\\工作记录\\BERT\\BERTCharacter.dump'
dic = {}
characterSet = {}
bc = BertClient()

hanzi = open(hanziPath, 'rb')
for line in hanzi.readlines():
    if len(line)!= 0:
        continue
    else:
        character = line.split()[0]
        characterSet.add(character)

# 取向量，写入字典
characterList = list(characterSet)
result = bc.encode(characterList)
for pair in zip(characterList, result):
    character = pair[0]
    embedding = pair[1]
    dic[character] = embedding
dump = open(hanziPath, 'wb')
pickle.dump(dic, dump)


########################## SCIRPT 26 ###############################
# 功能：tkinter将pdf打印在画布上，并获取用户鼠标点击的坐标，作为用户输入OK（但循环方式还没OK）
path = '#13太平福禄康瑞2018终身重大疾病保险@太平人寿保险有限公司.pdf'
pdf = pdfplumber.open(path)
p0 = pdf.pages[20]
width = p0.width
height = p0.height
im = p0.to_image()
im.save('1.png', format="PNG")

# 画图，获取鼠标坐标
win = tk.Toplevel()
win.title("点击4个点，将感兴趣内容框住")
canvas = tk.Canvas(win,width=width, height=height, bg='black')
canvas.pack()

img = tk.PhotoImage(file='1.png')
canvas.create_image(0,0, anchor=tk.NW, image=img)

frame = tk.Frame(win, width=width, height=height)
frame.bind("<Button-1>", GUI.callback_Tkinter)
frame.pack()

tk.mainloop()


