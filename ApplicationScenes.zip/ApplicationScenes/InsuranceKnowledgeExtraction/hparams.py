import argparse
from models_tf_seqTagging.utils import str2bool


def add_arguments(parser: argparse.ArgumentParser):
    """Build ArgumentParser."""
    assert isinstance(parser, argparse.ArgumentParser)
    # raw format transformation
    parser.add_argument("--docxFolder", type=str,
                        default='E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\docx\\',
                        help="")
    parser.add_argument("--xmlFolder", type=str,
                        default='E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\xml\\',
                        help="")

    # mysql database
    parser.add_argument("--mysql_user", type=str,
                        default='root',
                        help="")
    parser.add_argument("--mysql_password", type=str,
                        default='',
                        help="")
    parser.add_argument("--mysql_hostname", type=str,
                        default='localhost',
                        help="")
    parser.add_argument("--mysql_port", type=int,
                        default=3306,
                        help="")
    parser.add_argument("--mysql_schema", type=str,
                        default='insurknowledge',
                        help="")
    parser.add_argument("--mysql_charset", type=str,
                        default='utf8',
                        help="")

    # segmentation
    parser.add_argument("--LTP_DATA_DIR", type=str,
                        default='D:/User/Documents/PycharmProjects/GitHubProjects/ltp_data_v3.4.0',
                        help="")# ltp模型目录的路径
    parser.add_argument("--lexionPath", type=str,
                        default='D:/User/Documents/PycharmProjects/GitHubProjects/ltp_data_v3.4.0/lexicon',
                        help="")




    # Framework params
    parser.add_argument("--labeled_percent", type=float, default=0.1,
                        help="Initial labeled samples percentage of the whole training dataset.")
    parser.add_argument("--max_round", type=int, default=60,
                        help="Max rounds of framework iteration.")
    parser.add_argument("--num_select_per_round", type=int, default=200,
                        help="Num of samples to select per iteration.")
    parser.add_argument("--pre_train", type=bool, default=False,
                        help="Whether to load the pretrained model.")
    parser.add_argument("--decay_threshold", type=float, default=0.046,
                        help="The decay threshold of entropy framework.")
    parser.add_argument("--decay_rate", type=float, default=0.001,
                        help="The decay rate of entropy framework.")
    parser.add_argument("--hist_sel_mode", type=str, default=True,
                        help="Historical samples select mode, certain | var | no")

    # Model params
    parser.add_argument("--batch_size", type=int, default=16,
                        help="Mini batch size.")
    parser.add_argument("--learning_rate", type=float, default=0.0005,
                        help="Learning rate of the model.")
    parser.add_argument("--metric_baseline", type=float, default=0.686824,
                        help="Model accuracy over the baseline can be saved.")
    parser.add_argument("--num_epochs", type=int, default=50,
                        help="Total epochs to train.")
    parser.add_argument("--load_pretrained", type=bool, default=True,
                        help="Whether to load the pretrained model.")
    ############## Bi-LSTM ###############
    parser.add_argument("--model_path", type=str,
                        default='D:/User/Documents/PycharmProjects/GitHubProjects/ALFramework-master/data_path_save',
                        help="model Folder")
    parser.add_argument('--train_data', type=str,
                        default='D:/User/Documents/PycharmProjects/GitHubProjects/ALFramework-master/data_path',
                        help='train data source')
    parser.add_argument('--pretrain_embedding', type=str, default='BERT',
                        help='use pretrained char embedding or init it randomly. random | BERT | wordvec')
    parser.add_argument('--embedding_dim', type=int, default=300, help='random init char embedding_dim')
    parser.add_argument('--mode', type=str, default='demo_LU', help='train/test/demo/demo_LU')
    parser.add_argument('--demo_model', type=str, default='1556443860', help='model for test and demo')
    parser.add_argument('--test_data', type=str, default='data_path', help='test data source')
    parser.add_argument('--epoch', type=int, default=50, help='#epoch of training')
    parser.add_argument('--hidden_dim', type=int, default=100, help='#dim of hidden state')
    parser.add_argument('--optimizer', type=str, default='Adam', help='Adam/Adadelta/Adagrad/RMSProp/Momentum/SGD')
    parser.add_argument('--CRF', type=str2bool, default=True, help='use CRF at the top layer. if False, use Softmax')
    parser.add_argument('--lr', type=float, default=0.001, help='learning rate')
    parser.add_argument('--clip', type=float, default=5.0, help='gradient clipping')
    parser.add_argument('--dropout', type=float, default=0.5, help='dropout keep_prob')
    parser.add_argument('--update_embedding', type=str2bool, default=False, help='update embedding during training')
    parser.add_argument('--shuffle', type=str2bool, default=True, help='shuffle training data before each epoch')
    parser.add_argument('--base_model_exist', type=bool, default=True, help='是否已有base model')
    parser.add_argument('--sentenceMaxLen', type=int, default=300, help='是否已有base model')