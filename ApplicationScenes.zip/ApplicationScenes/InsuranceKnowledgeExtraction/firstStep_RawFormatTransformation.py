#encoding=UTF-8
'''
本模块完成将不同格式的数据源进行格式转换，例如pdf转txt
'''

import pandas as pd
import os
import codecs
import re
# from pdfminer.pdfparser import  PDFParser,PDFDocument
# from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
# from pdfminer.converter import PDFPageAggregator
# from pdfminer.layout import LTTextBoxHorizontal,LAParams
# from pdfminer.pdfinterp import PDFTextExtractionNotAllowed
from tool import isLegalFile




# 测试OK
# 清洗txt中的脏数据
def cleanDirtyCorpus(oneFilePath, outputFilePath):
    # 未解码成功：删除文档
    decodeSuccessFlag1 = isLegalFile(oneFilePath)  # 形如“#29广电日生附加广福定期寿险@长生人寿保险有限公司.txt”
    if decodeSuccessFlag1 == False:
        print("file %s meaningless" % oneFilePath)
        return -1
    # 有意义的文档，将数据进行清洗
    else:
        with codecs.open(oneFilePath, 'rb', encoding='utf-8') as inputFile:
            content = []
            for line in inputFile.readlines():
                # 页标行:忽略页码行
                subcriptFlag1 = re.search(r'第\s*[0-9]*\s*页', line)  # 形如“第 3 页，共 6 页”
                subcriptFlag2 = re.search(r'-\s*[0-9]*\s*-', line)  #形如“- 1 -”
                if subcriptFlag1!=None or subcriptFlag2!=None:
                    continue
                # 标题文字保留，但符号+页码去除：修改一行（形如“#20长城附加吉祥定期寿险@长城人寿保险股份有限公司.txt”）
                line = re.sub('\s*[.]+\s*[0-9]+', '', re.sub('[ ]+', '', line))
                # 将空行转化为分隔符“。”
                line = re.sub('(\r\n)', '。', line)
                # 去除特殊字符
                line = re.sub('[．.]', '', line)
                # 初步清洗的行写入content
                content.append(line)
            # 将多个“。”合并成1个
            content = re.sub('。+', '。\r\n', ''.join(content))
            with codecs.open(outputFilePath, 'wb', encoding='utf-8') as destFile:
                destFile.write(content)
    return 0
