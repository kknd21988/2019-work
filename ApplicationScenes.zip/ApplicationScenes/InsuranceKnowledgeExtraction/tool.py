#encoding=UTF-8
'''
本模块将建立知识图谱的公用函数，基础功能
'''
import codecs
import re
import numpy as np
import requests
import os
import copy
import csv
import pickle
import jieba
from jieba import posseg
from pyltp import Segmentor, Postagger, Parser, SementicRoleLabeller
from lxml import etree
from sklearn.feature_extraction.text import CountVectorizer
import xlrd
import sys
from sklearn import metrics
import warnings
from itertools import combinations



# B:Beginning/I:Intermediate/E:End/O:OutOfBoundary
authenticLabels = set(['B','I','E','O'])

# 词性标注集转换表：jieba——》LTP
polarityTransformation = {
            'n': 'n',
            'nr': 'nh',
            'nr1': 'nh',
            'nr2': 'nh',
            'nrf': 'nh',
            'nrj': 'nh',
            'ns': 'ns',
            'nsf': 'ns',
            'nt': 'ni',
            'nz': 'nz',
            'nl': 'n',
            'ng': 'n',
            't': 'nt',
            'tg': 'nt',
            's': 'nl',
            'f': 'nd',
            'v': 'v',
            'vd':'n',
            'vn': 'v',
            'vshi':'v',
            'vyou':'v',
            'vf':'v',
            'vx':'v',
            'vi':'n',
            'vl':'n',
            'vg':'n',
            'a': 'a',
            'ad': 'd',
            'an': 'a',
            'ag': 'a',
            'al': 'a',
            'b': 'b',
            'bl': 'b',
            'z': 'n',
            'r': 'r',
            'rr': 'r',
            'rz': 'r',
            'rzt': 'nt',
            'rzs': 'nl',
            'rzv': 'v',
            'ry': 'r',
            'ryt': 'nt',
            'rys': 'nl',
            'ryv': 'v',
            'rg ': 'r',
            'm': 'm',
            'mq': 'm',
            'q': 'q',
            'qv': 'q',
            'qt': 'q',
            'd': 'd',
            'p': 'p',
            'pba': 'p',
            'pbei' : 'p',
            'c': 'c',
            'cc': 'c',
            'u': 'u',
            'uzhe': 'u',
            'ule': 'u',
            'uguo': 'u',
            'ude1': 'u',
            'ude2': 'u',
            'ude3': 'u',
            'usuo': 'u',
            'udeng': 'u',
            'uyy': 'u',
            'udh': 'u',
            'uls': 'u',
            'uzhi': 'u',
            'ulian': 'u',
            'e': 'e',
            'y': 'e',
            'o': 'o',
            'h': 'h',
            'k': 'k',
            'x': 'nz',
            'xe': 'nz',
            'xs': 'nz',
            'xm': 'nz',
            'xu': 'nz',
            'w': 'wp',
            'wkz':'wp',
            'wky': 'wp',
            'wyz':'wp',
            'wyy': 'wp',
            'wj':'wp',
            'ww': 'wp',
            'wt': 'wp',
            'wd':'wp',
            'wf':'wp',
            'wn':'wp',
            'wm': 'wp',
            'ws': 'wp',
            'wp': 'wp',
            'wb': 'wp',
            'wh': 'wp',
            'g': 'g',
            'l': 'i',
            'R': 'h',
            # 以下因为jieba的一些词性不在转换表中，所以人为加入
            'ul': 'u',
            'uj': 'u',
            'uz': 'u',
            'uv': 'u',
            'ud': 'u',
            'ug': 'u',
            'j': 'n',
            'df': 'v',
            'dg': 'd',
            'vq': 'v',
}


# 状态：已测试
# 功能：根据pdf清单下载对应pdf文件
# url:pdf的链接
# name：pdf的名字
# localFolder：下载pdf的存放文件夹
# 例
# url = 'http://www.iachina.cn/IC/tkk/03/dca646fa-ccaf-4c57-b59e-661ba8849c01_TERMS.PDF'
# name = '太平家得乐购房贷款定期寿险（A款）'
# folder = 'E:/工作/保险语料/'
# download_file(url, name, folder)
def download_file(url, name, localFolder):
    local_filename = localFolder + name + '.pdf'
    # NOTE the stream=True parameter
    r = requests.get(url, stream=True)
    with open(local_filename, 'wb') as f:
        for chunk in r.iter_content(chunk_size=1024):
            if chunk: # filter out keep-alive new chunks
                f.write(chunk)
                f.flush()
    return local_filename

# 状态：测试OK
# 功能：提取NER的语料
# 找到entitySet中的每一个entity在rawText中的上下文，[]形式返回
# 上下文：entity所在句子+前一个句子+后一个句子。句子用句号判断
def getEntityContext(rawTextPath, markedTextPath, entityList):
    sentenceMark = '[。！？]'
    contextPrevious = []
    contextCurrent = []
    contextBehind = []
    result = {}
    with codecs.open(rawTextPath, 'rb', 'utf-8') as file:
        # 将所有换行符删除。按照sentenceMark来断句
        temp = file.read()
        sentences = re.split(sentenceMark, temp.replace('\r\n', ''))
        markedSentences = copy.copy(sentences)
        num = len(sentences)
        # 对种子实体名词，扫描一遍全量文本，找到其上下文
        for entity in entityList:
            for i in np.arange(num):
                if entity in markedSentences[i]:
                    # 前一句
                    if i-1 >=0:
                        contextPrevious.append(sentences[i-1])
                    # 当前句
                        contextCurrent.append(sentences[i])
                    # 后一句
                    if i+1 < num:
                        contextBehind.append(sentences[i+1])
                    # 将已经标示出的entity用#标示
                    markedSentences[i] = markedSentences[i].replace(entity, '#')
            result[entity] = {'contextPrevious': contextPrevious, 'contextCurrent': contextCurrent,
                              'contextBehind': contextBehind}
            contextPrevious = []
            contextCurrent = []
            contextBehind = []
        # 标示完所有实体的文本保存
        [temp, filename] = os.path.split(rawTextPath)
        with codecs.open(os.path.join(markedTextPath, filename), 'wb', encoding='utf-8') as wrFile:
            wrFile.writelines(markedSentences)

    return result

# 状态：已测试
# 功能：合并2个字典。向mainDic中添加已有域的不同值
def merge2Dic(mainDic, minorDic):
    for key, value in minorDic.items():
        if key not in mainDic:
            mainDic[key] = value
        elif isinstance(mainDic[key], type(value)) == False:
            print("Error: corresponding value is not the same type")
            return -1
        elif isinstance(mainDic[key], dict):
            merge2Dic(mainDic[key], value)
        elif isinstance(mainDic[key], list):
            mainDic[key] = list(set(mainDic[key]).union(set(value)))
    return 0

# 功能：将一个corpus里的每个字，按照labelDic的方式打好tag
# 1.rawTextPath：未打标签的语料
# 2.entityList：实体列表(！实体一定按照长度从长到短排序！)
# 3.resultCorpusPath：打好标签的corpus。格式为2列，一列为字，一列为对应的label
def getTaggedCorpus(rawTextPath, resultCorpusPath, entityList):
    sentenceMark = '[。！？]'
    with codecs.open(rawTextPath, 'rb', 'utf-8') as file:
        # 将所有换行符/空格删除。按照sentenceMark来断句
        temp = file.read()
        sentences = re.split(sentenceMark, temp.replace('\r\n', '').replace(' ', ''))
        markedSentences = [['O']*len(x) for x in sentences]
        num = len(sentences)
        # 对种子实体名词，扫描一遍全量文本，找到其上下文
        for entity in entityList:
            for i in np.arange(num):
                entityLen = len(entity)
                sentenceLen = len(markedSentences[i])

                entityMatchPlace = [(m.start(), m.end()) for m in re.finditer(entity, sentences[i])]    #注意：m.end()指向匹配字符的后一个字符
                for matchPos in entityMatchPlace:
                    if matchPos[0] == matchPos[1]-1:
                        if markedSentences[i][matchPos[0]] != 'O':  # 如果已经打了其他标签，则不覆盖
                            continue
                        else:
                            markedSentences[i][matchPos[0]] = 'S'  # 单字符实体
                    else:
                        if (markedSentences[i][matchPos[0]] != 'O') or (markedSentences[i][matchPos[1] - 1] != 'O'):
                            # 说明当前实体的开头或结尾在另一个更长的实体中间，因此这个实体忽略
                            continue
                        else:
                            markedSentences[i][matchPos[0]] = 'B'
                            markedSentences[i][matchPos[1]-1] = 'E'
                            markedSentences[i][matchPos[0]+1 : matchPos[1]-1] = 'I' * (matchPos[1]-matchPos[0]-2)
                            # for index in np.arange(matchPos[0]+1, matchPos[1]-1):
                            #     markedSentences[i][index] = 'I'
        # 标示完所有实体的文本保存
        content = []
        # 将原句和对应的一句tag组合在一起
        for x in list(zip(sentences, markedSentences)):
            sentence1 = x[0]
            sentence2 = x[1]
            # 将一句内的字和tag组合在一起
            for charAndTagpair in list(zip(sentence1, sentence2)):
                content.append(' '.join(list(charAndTagpair))+'\r\n')
            # 句子与句子之间用一个空行间隔开
            content.append('\r\n')
        with codecs.open(resultCorpusPath, 'wb', 'utf-8') as wrFile:
            wrFile.writelines(content)


    return 0

# 功能：将一个corpus里的每个字，按照labelDic的方式打好tag
# fileList：待合并的文件的路径名list
# mergedFilePath：合并后的文件路径名
def mergeFiles2One(fileList, mergedFilePath):
    with codecs.open(mergedFilePath, 'wb', encoding='utf-8') as merFile:
        for oneMarkedFile in fileList:
            with codecs.open(oneMarkedFile, 'rb', encoding='utf-8') as markedFile:
                # 从当前文件中读出
                content = markedFile.readlines()
                # 写入目标合并的文件
                merFile.writelines(content)
    return 0

# 检查句子中有多少是汉字
def check_contain_chinese(check_str):
    numChineseChar = 0
    numTotalChar = len(check_str)
    for ch in check_str:
        if u'\u4e00' <= ch <= u'\u9fff':
            numChineseChar += 1
    return numChineseChar, numTotalChar

# 判断一个文档中是否是有意义的信息，还是解码失败后的乱码
def isLegalFile(oneFilePath):
    flag = False
    # 逻辑1：读取文件的中间10个非空行，如果都不是有意义的行（汉字占比超过70%）或者都是超短行（长度小于6个汉字），则返回False。否则为True。
    with codecs.open(oneFilePath, 'rb', encoding='utf-8') as file:
        content = file.readlines()
        numLine = len(content)
        checkStart = int(numLine/2)
        checkEnd = checkStart+10
        if checkEnd >= numLine:
            # 文档行数太少
            return flag
        for line in content[checkStart: checkEnd+1]:
            [numChineseChar, numTotalChar] = check_contain_chinese( ''.join(line.split()) )
            if numTotalChar == 0:
                continue
            if (numChineseChar*1.0)/numTotalChar > 0.7\
                and numTotalChar >6:
                flag = True
                break   # 有一个正常行，说明文档是有意义的
    return flag

# 获取一个r节点内的内容，遵循如下原则
# 1.一个r节点中如果既有t，也有格式符如tab，则保留格式符
def getContentFromRNode(rNode):
    # 是否存在文本节点，若不存在文本节点，则直接返回
    contentNodeList = rNode.xpath('descendant::w:t|descendant::w:tab',namespaces=rNode.nsmap)
    content = ['\t' if re.sub(r'{(.*?)}', '', x.tag) == 'tab' else x.xpath('string()') for x in contentNodeList]
    return ''.join(content)


# 给定一个XML的node list，返回这个list中可以合并的文本
# task1:单个p内部的多个r的text如何合并？
# task2:多个p的text能否合并？
def getZoneContent(XMLNodeList):
    pNodeContentList = []   # 每个p的content合并后作为list的一个元素
    # 对每个pNode内的文本合并
    for pNode in XMLNodeList:
        rList = pNode.xpath('descendant::w:r', namespaces=pNode.nsmap)
        # 找到r中有上标的节点，删除
        rDelete = pNode.xpath('w:r[descendant::w:vertAlign[@w:val="superscript"]]', namespaces=pNode.nsmap)
        # 删除有上标的r节点
        for one in rDelete:
            rList.remove(one)
        # 列出每个rNode中的内容
        rContentList = [getContentFromRNode(k) for k in rList]
        pNodeContentList.append(''.join(rContentList))
    # 处理不同pNode之间的合并情况
    totalContent = '\r\n'.join(pNodeContentList)
    return totalContent

# 从给定的Zone（包含多个解释的节点）中提取多条解释，每条解释分别存入dic
def getExplanationDic(explanationZone):
    explanationDic = {}
    for item in explanationZone:
        contentList = item.xpath('descendant::text()')
        # 删除第一个节点元素
        content = ''.join(contentList[1:])
        # 以分号为分隔符，获取key和value
        if len(re.split('[：:]',content))!=2:
            error = 1
        key, value = re.split('[：:]',content)
        if key not in explanationDic.keys():
            explanationDic[key] = value
        else:
            raise RuntimeWarning("Key %s already exists! Existed value is %s, new value is %s"\
                                 % (key, explanationDic[key], value))
    return explanationDic

# 判断一个paragraph节点的类型：/
# H（heading）/IES(ItemExplanation Separator)/F(Footer)/IEC(ItemExplanation Content)/
# /CH(Content belonged to certain Heading)/CNH(Content Belonged to No Heading)
def getNodeType(XMLNode, flagHeading, flagExplanation):
    # 子标题2
    heading = XMLNode.xpath('descendant::w:pStyle[contains(@w:val,"Heading2")]', namespaces=XMLNode.nsmap)
    temp = XMLNode.xpath('descendant::text()', namespaces=XMLNode.nsmap)
    temp = re.search('第.条[\s]+[\u4e00-\u9fa5]+', '\t'.join(temp))
    # heading = XMLNode.xpath('descendant::w:pStyle[@w:val="3"]', namespaces=XMLNode.nsmap)
    if len(heading) != 0 or temp!=None:
        return 'Heading'
    else:
        # 专有词语解释分隔符
        ies = XMLNode.xpath('descendant::v:line', namespaces=XMLNode.nsmap)
        if len(ies) != 0:
            return 'ItemExplanationSeparator'
        else:
            # 脚注
            footer = XMLNode.xpath('descendant::*[@w:footer]', namespaces=XMLNode.nsmap)
            if len(footer) != 0:
                return 'Footer'
            else:
                # content：不属于以上类型的节点，并且含有t节点
                content = XMLNode.xpath('descendant::w:t', namespaces=XMLNode.nsmap)
                if len(content) != 0:
                    if flagExplanation == True:
                        return 'ItemExplanationContent'
                    elif flagHeading == True:
                        return 'Content_belonged_to_certain_Heading'
                    elif flagHeading == False:
                        return 'Content_Belonged_to_No_Heading'
                    else:
                        raise RuntimeWarning("Unknown Type Node")
                else:
                    return 'Other'

# 获取产品条款的唯一标识
# version1：公司名+产品名
def getClauseIdentity(path):
    identity = ''
    # 获取公司名+产品名。这两者的组合唯一标识一个产品条款
    productName, companyName = re.split(r'[(\\)/]', path)[-3].split('@')
    if companyName == None or productName == None:
        raise RuntimeError("No valid clause identity!")
    else:
        return companyName, productName


# 解析保险产品docx的xml文件
# 问题在于：pdf转到的docx的标签不稳定，例如会丢失部分标题结构，会将部分p分割为多块
# 所以处理这个问题，现在先把所有headingContent中有内容的p节点集中到一个list中，再处理这个list。思路和这个函数很相似，见Script9

def getEntityAndRelationFromXML(XMLPath):
    parser = etree.XMLParser()
    root = etree.parse(XMLPath, parser).getroot()
    dicHeadingContent = {}  # 标题和对应的内容存储在里面
    dicTerminology = {}  # 专有名词和对应的解释存储在里面
    # 找到所有pStyle为Heading2的 <w:p> element
    wpNodeList = root.xpath('w:body/w:p', namespaces=root.nsmap)
    flagHeading = False
    flagExplanation = False
    heading = ''
    lastHeading = ''
    contentZone = []
    explanationZone = []
    for element in wpNodeList:
        # 判断当前p是什么类型
        elementType = getNodeType(element, flagHeading, flagExplanation)
        # 如果p是heading
        if elementType == 'Heading':
            print("Headings Begin")
            flagHeading = True
            lastHeading = copy.copy(heading)
            heading = ' '.join(element.xpath('descendant::text()'))
            if len(lastHeading) != 0:
                # 遇到新heading，将内容联系到上一个heading
                dicHeadingContent[lastHeading] = getZoneContent(contentZone)
                contentZone = []
        # 如果p是名词解释分隔符——太平人寿产品中出现
        elif elementType == 'ItemExplanationSeparator':
            print("Separator Begin")
            flagExplanation = True
        # 如果p是footer:将flagExplanation复原
        elif elementType == 'Footer':
            print("Footer happens")
            if flagExplanation == True:
                dicTerminology.update(getExplanationDic(explanationZone))
                explanationZone = []
                flagExplanation = False
        # 如果p不是以上各种，那就可能是content
        elif elementType == 'ItemExplanationContent':
            print("ItemExplanationContent happens")
            explanationZone.append(element)
        elif elementType == 'Content_belonged_to_certain_Heading':
            print("Content_belonged_to_certain_Heading happens")
            contentZone.append(element)
        elif elementType == 'Content_Belonged_to_No_Heading':
            print("Content_Belonged_to_No_Heading happens :%s" % element.xpath('descendant::text()'))
            continue
        elif elementType == 'Other':
            print("Other happens")
            continue
        else:
            raise RuntimeWarning("Warning")
    return dicHeadingContent, dicTerminology

# 取出保险产品条款中指定heading的content
def getHeadingContent(xmlPath, givenHeading):
    parser = etree.XMLParser()
    root = etree.parse(xmlPath, parser).getroot()
    headingContent = ''
    # 0.找出所有p节点，作为我们处理的全集
    pList = root.xpath('descendant::w:p', namespaces=root.nsmap)
    terminationList = []
    headingContentList = []
    flagHeading = False
    flagExplanation = False
    # PART1:把p放到对应的区域中
    # 1.定位正文区域的开头：第一个heading1处
    # 2.将正文区域的所有p节点分为2部分：名词定义区域 和 其他区域
    # 名词定义区域：定义分隔符开始的p——紧接着的第一个footer的p
    # 其他区域：包含了子标题和对应的内容
    pLen = len(pList)
    flagContentBegin = False
    for pNode in pList:
        nodeType = getNodeType(pNode, flagHeading, flagExplanation)
        if flagContentBegin == True:
            # content范围内，分隔符和footer之间的是“terminology”，其他都是“headingContent”
            # 如果p是名词解释分隔符——太平人寿产品中出现
            if nodeType == 'ItemExplanationSeparator':
                print("Separator Begin")
                flagExplanation = True
            # 如果p是footer:将flagExplanation复原
            elif nodeType == 'Footer':
                print("Footer happens")
                flagExplanation = False
            elif nodeType == 'ItemExplanationContent':
                print("ItemExplanationContent happens")
                terminationList.append(pNode)
            else:
                print("HeadingContent happens")
                headingContentList.append(pNode)
        else:
            # 第一个Heading1之前的都是目录
            if len(pNode.xpath('descendant::w:pStyle[contains(@w:val,"Heading1")]', namespaces=pNode.nsmap)):
                flagContentBegin = True
                flagHeading = True
                headingContentList.append(pNode)
            else:
                continue
    # 4.从其他区域抽取内容，存入dicHeadingContent。
    #  处理的是List。要把这个list尽量控制的简单，只有heading和content
    flagExplanation = False
    flagHeading = False
    heading = ''
    lastHeading = ''
    contentZone = []
    for element in headingContentList:
        # 判断当前p是什么类型
        elementType = getNodeType(element, flagHeading, flagExplanation)
        # 如果p是heading
        if elementType == 'Heading':
            print("Headings Begin")
            flagHeading = True
            lastHeading = copy.copy(heading)
            heading = ''.join(element.xpath('descendant::text()'))
            heading = re.sub('\s', '', heading)  # 将所有的空白字符删除
            print("%s" % heading)
            result = re.search('第.{1,}条([\u4e00-\u9fa5]+[\S]{0,})', heading)
            heading = result.group(1) if result != None else heading

            if givenHeading == lastHeading:
                # 遇到新heading，将内容联系到上一个heading
                headingContent = getZoneContent(contentZone)
                return headingContent
            # 出现一个heading，把上个heading的content清除
            contentZone = []
        # 如果p是名词解释分隔符——太平人寿产品中出现
        elif elementType == 'ItemExplanationSeparator':
            print("Separator Begin")
            flagExplanation = True
        # 如果p是footer:将flagExplanation复原
        elif elementType == 'Footer':
            print("Footer happens")
        # 如果p不是以上各种，那就可能是content
        elif elementType == 'ItemExplanationContent':
            print("ItemExplanationContent happens")
        elif elementType == 'Content_belonged_to_certain_Heading':
            print("Content_belonged_to_certain_Heading happens")
            contentZone.append(element)
        elif elementType == 'Content_Belonged_to_No_Heading':
            print("Content_Belonged_to_No_Heading happens :%s" % element.xpath('descendant::text()'))
            continue
        elif elementType == 'Other':
            print("Other happens")
            continue
        else:
            raise RuntimeWarning("Warning")
    # 没有发现指定标题
    print("No Occurrence of heading %s at document %s" % (givenHeading, xmlPath))


# 将字典中的键值对写入csv，一个键值对一行（字典中没有多层结构）
# keyValueRelation:指出key与value的关系
# option:指出要写入csv的对象（'key';'value';'key-relation-value'）
def writeDic2CSV(dic, destFilePath, option='key-relation-value', relation=None):
    with open(destFilePath, 'a', newline='', encoding='utf-8') as file:
        csv_writer = csv.writer(file, dialect='excel')
        # 写入
        if option == 'key':
            csv_writer.writerows([[x] for x in list(dic.keys())])
        elif option == 'value':
            csv_writer.writerows([[x] for x in list(dic.values())])
        elif option == 'key-relation-value':
            for key,value in dic.items():
                csv_writer.writerow([key, relation, value])
        else:
            raise RuntimeWarning("Unknown option: %s" % option)
    return 0

# 功能：获取line指定位置的order-gram
def get_ngram(line, pos, order):
    if pos < 0:
        return None
    if pos + order > len(line):
        return None
    ngram = line[pos]
    for i in range(1, order):
        ngram = ngram + line[pos + i]
    return ngram

# 将jieba词典中的词性转换为LTP的词性，因为要使用LTP的句法分析工具
# 输入：词典需要有word、freq、polarity三项
def wordPolarityTransformation(srcDicPath, destDicPath):
    srcContent = []
    destContent = []
    # 将原始字典读出
    with codecs.open(srcDicPath, 'rb', encoding='utf-8') as srcFile:
        srcContent = srcFile.readlines()
    # 扫描原始字典，对照转换表进行转换
    for item in srcContent:
        if len(item.strip()) == 0:
            continue
        else:
            word, freq, polarity = item.split()
            if polarity in polarityTransformation:
                newPolarity = polarityTransformation[polarity]
                destContent.append('{a}\t{b}\t{c}\r\n'.format(a=word, b=freq, c=newPolarity))
            else:
                raise RuntimeWarning("word %s 's polarity %s not in transformation\
                 dictionary" % (word, polarity))
                continue

    # 将转换后的字典保存
    with codecs.open(destDicPath, 'wb', encoding='utf-8') as destFile:
        destFile.writelines(destContent)
    return 0

# 将保险文档写成标题-内容后，将每段内容进行词法分析和句法分析，也写入字典中。
# 从titleContentDicPath的dump字典读入，分析结果存入newDicPath
# titleContentDicPath:标题-内容字典
# newDicPath：分析结果保存的字典
# destDicPath：分词依据的词典
# par_model_path：依存句法分析模型
# srl_model_path：语义角色标注模型
def analyzeKeyContent(titleContentDicPath, newDicPath, destDicPath, par_model_path, srl_model_path):
    file = open(titleContentDicPath, 'rb')
    dic = pickle.load(file)
    newDic = {}
    newDic['company'] = dic['company']
    newDic['product'] = dic['product']
    newDic['detail'] = {}

    jieba.load_userdict(destDicPath)
    # 句法分析
    parser = Parser()  # 初始化实例
    parser.load(par_model_path)  # 加载模型
    # 语义角色
    labeller = SementicRoleLabeller()  # 初始化实例
    labeller.load(srl_model_path)  # 加载模型
    for key, content in dic['detail'].items():
        # 将字典中每一段话都进行分词、句法分析、语义角色标注

        # 分句
        sentences = [sentence for sentence in re.split(r'[？?！!。\n\r]', content) if sentence]

        # 分词+词性标注
        words = []
        postags = []
        for oneSentence in sentences:
            wordOneSentence = []
            flagOneSentence = []
            result = posseg.cut(oneSentence)
            for word, flag in result:
                wordOneSentence.append(word)
                flagOneSentence.append(flag)
            # 一句的分析结果保存
            words.append(wordOneSentence)
            postags.append(flagOneSentence)

        # 句法分析
        # words = ['元芳', '你', '怎么', '看']
        # postags = ['nh', 'r', 'r', 'v']
        length = 0
        if len(words) == len(postags):
            length = len(words)
        else:
            raise RuntimeError("word number doesn't match postag number!")
        # arcList和arcObjects里面含有的是同一对象，只是格式不同
        arcList = []
        arcObjects = []
        for i in np.arange(length):
            arcs = parser.parse(words[i], postags[i])  # 句法分析
            arcObjects.append(arcs)
            arcListOneSentence = [(x[0].head, x[0].relation, x[1]) for x in zip(arcs, words[i])]
            arcList.append(arcListOneSentence)
            for pair in arcListOneSentence:
                print("\t".join("%d:%s(%s)" % (pair[0], pair[1], pair[2])))

        # 语义角色
        roles = []
        for i in np.arange(length):
            rolesOneSentence = labeller.label(words[i], postags[i], arcObjects[i])  # 语义角色标注
            rolesOneSentencetemp = []   # 对rolesOneSentenc进行翻译
            for role in rolesOneSentence:
                rolesOneSentencetemp.append([role.index])
                rolesOneSentencetemp[-1].append([(arg.name, arg.range.start, arg.range.end) for arg in role.arguments])
                print(role.index, "".join(
                    ["%s:(%d,%d)" % (arg.name, arg.range.start, arg.range.end) for arg in role.arguments]))

            roles.append(rolesOneSentencetemp)
        # 写入字典
        newDic['detail'][key] = {'content': content, 'words': words, 'postags': postags, \
                       'arcList': arcList, 'roles': roles}
    parser.release()  # 释放模型
    labeller.release()  # 释放模型
    # 保存字典
    with open(newDicPath, 'wb') as file:
        pickle.dump(newDic, file)
    return 0

# 将“一句话”的依存句法分析结果转化为ConLL格式
# ConLL格式说明：https://blog.csdn.net/qq_37667364/article/details/85110094
# 依存句法分析结果格式说明：[(arc.headIndex, arc.relation, 当前词语内容),(),...,()]（一句话为一个list）
# 输入为字典，格式如analyzeKeyContent中newDic的结构
def convertLTPresult2ConLL(words, postags, arcList, ConLLPath):
    with codecs.open(ConLLPath, 'a+', encoding='utf-8') as ConLLFile:
        contentOneSentence = []
        index = 0
        for item in zip(words, postags, arcList):
            index += 1
            word = item[0]
            pos = item[1]
            arcHead = item[2][0]
            arcRelation = item[2][1]
            # wordCheck = item[2][2]
            # if word != wordCheck:
            #     raise RuntimeError("word and DP result don't match")
            contentOneSentence.append('\t'.join([str(index), word, word, pos, pos, '_', str(arcHead), arcRelation, '_', '_'])\
                                      + '\r\n')
        # 一句话处理完，用一个空行结尾
        contentOneSentence += '\r\n'
        # 写入
        ConLLFile.writelines(contentOneSentence)
    return 0

# 将人工填写的xlsx转换为utf-8的csv文件
def xlsx2csv(xlsxPath, csvPath, encoding='utf-8'):
    content = []
    with xlrd.open_workbook(xlsxPath) as xlsxFile:
        sheets = xlsxFile.sheets()
        for i in range(sheets[0].nrows):
            row = sheets[0].row_values(i)
            content.append(row)
    with open(csvPath, 'w', newline='', encoding='utf-8') as file:
        csv_writer = csv.writer(file, dialect='excel')
        csv_writer.writerows(content)
    return 0


########################## 分类 ###############################
# 功能：测试分类结果
def calculate_accurate(actual,predict):
    m_precision = metrics.accuracy_score(actual,predict)
    print("计算结果：")
    print("精确度：{0:.3f}".format(m_precision))
    return 0

#计算精确度，召回率，f1值
'''
不知道为什么要设置average='macro' 当默认设置时，出错：后期将要的问题
'''
def calculate_3result(actual,predict):
    m_precison = metrics.precision_score(actual,predict,average='macro')
    m_recall = metrics.recall_score(actual,predict,average='macro')
    m_f1 = metrics.f1_score(actual,predict,average='macro')
    print("计算结果：")
    print("精确度：{0:.3f}".format(m_precison))
    print("召回率：{0:.3f}".format(m_recall))
    print("f1-score:{0:.3f}".format(m_f1))
    return 0

     #综合测试报告
def predict_result_report(actual,predict,catetory):
    print(metrics.classification_report(actual,predict,target_names=catetory))
    return 0


# 给出多个条款的“投保范围”的内容集合csv，获取“投保年龄”“续保年龄”“其他限制”的答案
def getCoverScope(csvPath, patternPath):
    file = open(csvPath, 'r', newline='', encoding='utf-8')
    csv_reader = csv.reader(file, dialect='excel')
    patternCount = {}
    for row in csv_reader:
        content = row[-1]
        # 文本预处理
        content = re.sub(r'[\s]+', '', content)
        # 数字替换为NUMBER
        content = re.sub(r'[0-9]+', 'NUMBER', content)
        # 找出数字出现的句子（句号为准）
        sentences = content.split('。')
        for oneSentence in sentences:
            oneSentence += '。'
            if len(oneSentence) == 0:
                continue
            if 'NUMBER' in oneSentence:
                if oneSentence in patternCount:
                    patternCount[oneSentence] += 1
                else:
                    patternCount[oneSentence] = 1
    file.close()
    # 统计信息写入csv
    patternFile = open(patternPath, 'w', newline='')
    csv_writer = csv.writer(patternFile, dialect='excel')
    temp = []
    for key, value in patternCount.items():
        temp.append([key, value])
    csv_writer.writerows(temp)
    # 模板提取:现在是人工截取，不能做到自动化

    return 0

# 将人工筛选的模板文件 转换为 python的正则表达式
# 测试OK.但使用起来不方便，因为转换后的字符串再次读入时，'\S'会变成'\\S'
def manualPattern2PythonRegularExpression(manualPatternPath, PythonRegularExpressionPath):
    with open(manualPatternPath, 'r', encoding='utf-8') as mPattern:
        with open(PythonRegularExpressionPath, 'w', newline='', encoding='utf-8') as PyPattern:
            content = []
            reader = csv.reader(mPattern)
            for row in reader:
                pattern = re.sub(r'ANYCONTENT', '.+?', row[-1])
                pattern = re.sub(r'START', r'(?P<START>.*?)', pattern)
                pattern = re.sub(r'END', r'(?P<END>.*?)', pattern)
                pattern = '.*?' + pattern + '.*?'
                content.append([row[0], pattern])
            writer = csv.writer(PyPattern)
            writer.writerows(content)
    return 0



# 给定模板pattern，提出信息
# 如果有大模板包含了小模板，都能产生匹配，则使用大模板匹配的结果
def blankFilling_CoverScope(patternPath, originalFile, finalFile):
    patternFile = open(patternPath, 'r', encoding='utf-8')
    originalFile = open(patternPath, 'r', newline='', encoding='utf-8')
    finalFile = open(patternPath, 'r', newline='', encoding='utf-8')
    finalFieldNames = ['ProductName','CompanyName', 'content', '']
    for line in patternFile:
        hello=1

# 判断2个词是否是同义词
def wordSimilarity(A, B, way='word2vec'):
    if way == 'word2vec':   # 直接用word2vec的向量比较
        # 指定同义词的最大距离
        synonymList = '男子汉 硬汉 纯爷们'.split()
        standard = [np.array(wv[x]) for x in synonymList]
        threshold = max([np.linalg.norm(pair[0]-pair[1]) \
                         for pair in combinations(synonymList, 2)])
        # 判断
        distance = np.linalg(wv[A] - wv[B])
        if distance > threshold:
            return 0
        else:
            return 1

# 获取中文词的dense vector
# 输入：一个词
# 输出：dense vector
def getDenseVector(word, choose='wordvec'):
    return 0


# question中知识图谱节点检测：entity coreference
def getKGEntity(questionEntityList, KGEntityList):
    # 取出KG中所有实例的dense vector
    KGEntityVecList = [getDenseVector(x) for x in KGEntityList]
    # 选出距离最近的KGEntity
    for entity in questionEntityList:
        getDenseVector(entity)

    # 将Q的entity和对应最可能的entity计算距离，如果大于阈值，则代表KG中没有对应的节点

    return 0


def preprocessString(str):
    '''
    将
    :param str:
    :return:
    '''