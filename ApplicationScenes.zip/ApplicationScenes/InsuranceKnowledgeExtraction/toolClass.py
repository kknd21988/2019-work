#encoding=utf-8
# 将tool中工具作为类的方法

import codecs
import pickle
import os
import xlrd
import re
import sys
import csv
import copy

# 词法：jieba分词，并和LTP的词性标注对齐
# 句法：依存句法和语义角色标注都用pyltp
class luParser:
    def __init__(self, sourceFolder, resultFolder):
        # 源数据路径、目标数据存放路径(如果路径很多，则在外部维护。否则直接写在类里面)
        # configPath = './config.txt'
        # sourcePath = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿的寿险产品\\KnowledgeGraph\\sourcePath'
        # resultPath = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿的寿险产品\\KnowledgeGraph\\resultPath'
        self.sourcePath = sourceFolder
        self.sourceFileList = []
        self.resultPath = resultFolder

    def getFileList(self):
        if os.path.isdir(self.sourcePath) == False:
            raise RuntimeError("Input Path should be a folder!")
        else:
            fileName = os.listdir(self.sourcePath)
            self.sourceFileList = [os.path.join(self.sourcePath, name) for name in fileName]
        return 0
    # 标题——内容
    def extractHeadingContentEvent(self, dicDumpPath, resultCSVPath):
        for oneSourceFile in self.sourceFileList:
            with open(dicDumpPath, 'rb') as file:
                dic = pickle.load(file)


        return 0

    # 名词——解释
    def extractNounTerminology(self, dicDumpPath, resultCSVPath):

        return 0

    # 实体——关系——实体
    def extractTriple(self, dicDumpPath, resultCSVPath):

        return 0

    # 标题——实体
    def extractHeadingEntity(self, dicDumpPath, resultCSVPath):

        return 0

    # 标题——事件
    def extractHeadingEvent(self, dicDumpPath, resultCSVPath):

        return 0


class knowledgeExtractionFromOpenSource:
    def __init__(self):
        hello = 1

    def tempScript(self, xlsxPath, knowledgePath, sheetIndex=0):
        with xlrd.open_workbook(xlsxPath) as xlsxFile:
            sheets = xlsxFile.sheets()
            MinZuEntity = []
            ProvinceEntity = []
            cityEntity = []
            relation = {}   # 提取省市的包含关系
            if sheetIndex == 0 or sheetIndex == 1:
                # 民族 or 国家
                content = sheets[sheetIndex]
                for i in range(content.nrows):
                    MinZuEntity.append([content.row_values(i)[1]])
                # 保存知识
                with open(knowledgePath, 'w', newline='', encoding='utf-8') as file:
                    csv_writer = csv.writer(file, dialect='excel')
                    csv_writer.writerows(MinZuEntity)
            elif sheetIndex == 2:
                # 省市：提取省、市实体；提取省、市包含关系；提取省、市名称的简称（去掉“省”、“市”）
                content = sheets[sheetIndex]
                # 提取实体
                province = ''
                lastProvince = ''
                provinceCorrespondingCity = []
                for i in range(content.nrows):
                    temp = content.cell(i,0).value
                    if '省' in temp or '自治区' in temp:
                        ProvinceEntity.append([temp])
                        lastProvince = copy.copy(province)
                        province = temp
                        # 省市对应关系
                        if len(provinceCorrespondingCity)!=0:
                            # 写入上一个省包含的城市，并清空
                            relation[lastProvince] = provinceCorrespondingCity
                            provinceCorrespondingCity = []
                    else:
                        cityBelongToOneCity = [[x] for x in temp.split()]
                        cityEntity.extend(cityBelongToOneCity)
                        # 省市对应关系
                        provinceCorrespondingCity.extend(temp.split())
                # 处理结束时，最后一个省份包含的城市信息写入
                relation[province] = provinceCorrespondingCity
                # 保存实体知识
                # with open(knowledgePath, 'w', newline='', encoding='utf-8') as file:
                #     csv_writer = csv.writer(file, dialect='excel')
                #     if len(ProvinceEntity) != 0:
                #         csv_writer.writerows(ProvinceEntity)
                #     elif len(cityEntity) != 0:
                #         csv_writer.writerows(cityEntity)
                #     else:
                #         print("Empty Row!")
                # 保存省份-城市关系知识
                with open(knowledgePath, 'w', newline='', encoding='utf-8') as file:
                    csv_writer = csv.writer(file, dialect='excel')
                    content = []
                    for province, citys in relation.items():
                        for city in citys:
                            content.append([city, '位于', province])
                    csv_writer.writerows(content)


        return 0

