#coding=UTF-8
import importlib
import sys
import time
import pandas as pd
from tool import mergeFiles2One
from random import shuffle
from math import ceil, floor

importlib.reload(sys)

# print("初始时间为：",time1)

import os.path
import pandas as pd
import codecs
import numpy as np
# from pdfminer.pdfparser import  PDFParser,PDFDocument
# from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
# from pdfminer.converter import PDFPageAggregator
# from pdfminer.layout import LTTextBoxHorizontal,LAParams
# from pdfminer.pdfinterp import PDFTextExtractionNotAllowed
from tool import getEntityContext
from firstStep_RawFormatTransformation import parsePDF2TXT, cleanDirtyCorpus
from tool import getEntityContext
from tool import merge2Dic, getTaggedCorpus
import xlrd
from tool import download_file, wordPolarityTransformation, analyzeKeyContent
import re
import pandas as pd
import pickle
from lxml import etree#导入lxml库
from tool import getZoneContent, getNodeType, getExplanationDic, getClauseIdentity, convertLTPresult2ConLL, xlsx2csv, getCoverScope
from tool import manualPattern2PythonRegularExpression, getHeadingContent
import copy
from py2neo import Graph,Node,Relationship, NodeMatcher
import jieba
from jieba import posseg
from sklearn.feature_extraction.text import CountVectorizer
import csv
import zipfile
import shutil
from sklearn.metrics import *
from bert_serving.client import BertClient
















# 功能：找出条款中“本合同终止”、“终止”和“中止”发生的条件

########################## SCIRPT 9 ###############################
# 提取出所有产品的“投保范围”：产品名 公司名 投保范围文本
givenHeading = '保险责任'
content = [['产品名', '公司名', givenHeading]]
folder = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\xml'
summaryFolder = 'E:\\工作记录\\保险行业语料\\保险合同\\保险数据\\太平人寿2019年1月仍在售\\summary'
# 解析xml，从中取出产品名+公司名+指定标题的内容
xmlFileList = os.listdir(folder)
for xmlFile in xmlFileList:
    # 取出公司名
    name = os.path.splitext(xmlFile)
    productName, companyName = name[0].split('@')
    productName = re.sub(r'#[0-9]+', '', productName)
    # 解析xml
    xmlFullPath = os.path.join(folder, xmlFile)
    headingContent = getHeadingContent(xmlFullPath, givenHeading)
    # 内容保存
    ContentThisRound = [productName, companyName, headingContent]
    content.append(ContentThisRound)
# 所有产品的指定heading下内容一次性写入
csvName = os.path.join(summaryFolder, givenHeading + '.csv')
with open(csvName, 'w', encoding='utf-8', newline='') as file:
    csv_writer = csv.writer(file, dialect='excel')
    csv_writer.writerows(content)
















hello=1






# content = '我们在收到保险金给付申请书及合同约定的证明和资料后，将在5个工作日内作出核定；情形复杂的，\
# 在 30 日内作出核定。对属于保险责任的，我们在与受益人达成给付保险金的协议后10日内，履行给付保险\
# 金义务。'
content = '我们在与受益人达成给付保险金的协议后10日内，履行给付保险金义务。'
# 0.预处理

# 1.将条款转化为标题-内容的字典

# 2.对于每个标题的内容，从中识别出标题涉及到的名词。
# 存入词典dicHeadingElements {heading:([relatedNouns], [relatedEvents])}
# for heading, content in dicHeadingContent.items():

# 3.对于每个标题的内容，从中识别出标题涉及到的事件

# 4.识别事件间的关系：主要是“条件——结果”和“属性——属性值”两类关系

# 5.做完以上工作，就可以设计算法比较子标题对应的关键保险事件了







