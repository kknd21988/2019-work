#coding=utf-8
from data_Utility.data_utils import BERTDenseVector, InteractiveTagging, trainData
from data_utils import generateInfoCombination, BERTDenseVector
from models_tf_seqTagging.data import seqTaggingDataContainer, tag2label_insurance
import pickle
from pyltp import Segmentor, SentenceSplitter
import os
import re
import pickle
from bert_serving.client import BertClient
import numpy as np




# 已标注数据
unlabeledCSVPath = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\zh-NER-TF-temp\\data_path\\保险责任.csv'
manuallyTaggingFilePath = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\zh-NER-TF-temp\\data_path\\manualTagging.txt'
data = seqTaggingDataContainer(unlabeledCSVPath,
                               manuallyTaggingFilePath,
                               tag2label_insurance)

data.askUserToLabel()
sentenceInfo = data.getSentenceInfoFromSemiLabel()
data.getFullyLabelFromSentenceInfo(sentenceInfo)




###################### 只有未标注语料的情况下，获取语料中各词的bert向量 ###########################
# 生成bert向量词典

## 根据要标记的语料生成
# 分词模型
LTP_DATA_DIR='D:\\User\\Documents\\PycharmProjects\\KG\\EventTriplesExtraction_master\\ltp_data_v3.4.0\\'  # ltp模型目录的路径
cws_model_path = os.path.join(LTP_DATA_DIR, 'cws.model')  # 分词模型路径，模型名称为`cws.model`
segmentor = Segmentor()  # 初始化实例
segmentor.load_with_lexicon(cws_model_path, 'lexicon')  # 加载模型，第二个参数是您的外部词典文件路径
# 收集原始语料、去除空白字符
unlabeledCSVPath = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\zh-NER-TF-temp\\data_path\\保险责任.csv'
manuallyTaggingFilePath = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\zh-NER-TF-temp\\data_path\\manualTagging.txt'
data = seqTaggingDataContainer(unlabeledCSVPath,
                               manuallyTaggingFilePath,
                               tag2label_insurance)
unlabelRowBegin = 19
unlabelRowEnd = 115
col = 2
data.gatherUnlabeledSeq(unlabelRowBegin, unlabelRowEnd, col)
# 生成wholeword2id
key = '123'   #确保wholeword2id和bertEmbedding对应
wholeword2idFile = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\zh-NER-TF-temp\\data_path\\wholeword2id'+key+'.pkl'
bertEmbeddingFile = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\zh-NER-TF-temp\\data_path\\bertEmbedding'+key+'.npy'
if os.path.exists(wholeword2idFile):
    rdFile = open(wholeword2idFile, 'rb')
    wholeword2id = pickle.load(rdFile)
else:
    wholeword2id = {}
    wordSet = set(['<UNK>'])
    # rawPath = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\zh-NER-TF-temp\\data_path\\rawCorpus.txt'
    for line in data._data_unlabeled:
        wordSet = wordSet.union(set(line))
    wholeword2id = dict(zip(wordSet, range(len(wordSet))))
    with open(wholeword2idFile, 'wb') as wrFile:
        pickle.dump(wholeword2id, wrFile)

# 原始语料分词，分词结果查bert，形成word2id和embedding array
bertVec = BERTDenseVector()
tokenList = sorted(wholeword2id.keys(), key=lambda x:wholeword2id[x], reverse=False)
vecList = bertVec.getDenseVector(tokenList, onlyQuery=True)
np.save(bertEmbeddingFile, np.array(vecList))

# 检验OK


###################### 提取保险信息抽取测试数据（未标注） ###########################
manuallyTaggingFilePath = "D:/User/Documents/PycharmProjects/GitHubProjects/zh-NER-TF-temp/data_path/manualTagging.txt"
rawPath = 'D:/User/Documents/PycharmProjects/GitHubProjects/zh-NER-TF-temp/data_path/其他保险公司保险责任.csv'
testPath = "D:/User/Documents/PycharmProjects/GitHubProjects/zh-NER-TF-temp/data_path/保险责任-测试集.txt"
container = seqTaggingDataContainer(manuallyTaggingFilePath)
container.gatherUnlabeledSeqFromCSV(rawPath,1,16,2)
with open(testPath, 'a', encoding='utf-8') as wrFile:
    content = ['\n']
    for line in container._data_unlabeled:
        content.append('(O) '.join(line))
        content.append('\n\n')
    wrFile.writelines(content)










# 已标注数据
# unlabeledCSVPath = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\zh-NER-TF-temp\\data_path\\保险责任.csv'
# manuallyTaggingFilePath = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\zh-NER-TF-temp\\data_path\\manualTagging.txt'
# data = seqTaggingDataContainer(unlabeledCSVPath,
#                                manuallyTaggingFilePath,
#                                tag2label_insurance)
# data.gatherInfor()
# # data.getSentenceToBeTagged(34, 2)
# # data.askUserToLabel()
# # sentenceInfo = data.getSentenceInfoFromSemiLabel()
# # data.getFullyLabelFromSentenceInfo(sentenceInfo)
# # 未标注数据
# unlabelRowBegin = 19
# unlabelRowEnd = 115
# col = 2
# data.gatherUnlabeledSeq(unlabelRowBegin, unlabelRowEnd, col)
#
#
# data.gatherInfor()
# infoDict = data.infoDict
# sentenceInfo = data.sentenceInfo
# corpusPath = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\zh-NER-TF-temp\\data_path\\generatedCorpus.txt'
# generateInfoCombination(infoDict, sentenceInfo, corpusPath)

# ex = InteractiveTagging()
# ex.wordTagging(startLine=18)

