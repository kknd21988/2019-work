
from data_utils import BERTDenseVector, InteractiveTagging, trainData
from data_utils import generateInfoCombination

# bert = BERTDenseVector()
# bert.updateDenseVector()
# bert.writeDenseVector2TXT()

# taggedWord = 'D:\\User\\Documents\\PycharmProjects\\GitHub\sequence_tagging-master-tf\\data\\保险责任-taggedWord.txt'
# with open(taggedWord, 'r', encoding='utf-8') as file:
#     lines = file.readlines()
#     hello=1



data = trainData()
data.gatherInfor()
infoDict = data.infoDict
sentenceInfo = data.sentenceInfo
corpusPath = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\zh-NER-TF-temp\\data_path\\generatedCorpus.txt'
generateInfoCombination(infoDict, sentenceInfo, corpusPath)

# ex = InteractiveTagging()
# ex.wordTagging(startLine=18)

