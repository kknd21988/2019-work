import numpy as np
import os
import csv
import re
import copy
import itertools
import random
from pyltp import Segmentor, SentenceSplitter
from bert_serving.client import BertClient
from collections import Iterable

# 分词模型
LTP_DATA_DIR='D:\\User\\Documents\\PycharmProjects\\KG\\EventTriplesExtraction_master\\ltp_data_v3.4.0\\'  # ltp模型目录的路径
cws_model_path = os.path.join(LTP_DATA_DIR, 'cws.model')  # 分词模型路径，模型名称为`cws.model`

# shared global variables to be imported from model also
UNK = "$UNK$"
NUM = "$NUM$"
NONE = "O"


# special error message
class MyIOError(Exception):
    def __init__(self, filename):
        # custom error message
        message = """
ERROR: Unable to locate file {}.

FIX: Have you tried running python build_data.py first?
This will build vocab file from your train, test and dev sets and
trimm your word vectors.
""".format(filename)
        super(MyIOError, self).__init__(message)

class BERTDenseVector():
    """
    bert无法处理空字符，如\n，\t等

    """
    def __init__(self):
        self.rawTextPath = 'D:\\User\\Documents\\PycharmProjects\\GitHub\sequence_tagging-master-tf\\data\\保险责任.csv'
        self.denseVectorPath = 'D:\\User\\Documents\\PycharmProjects\\GitHub\sequence_tagging-master-tf\\data\\bertDenseVector.txt'
        segmentor = Segmentor()  # 初始化实例
        segmentor.load_with_lexicon(cws_model_path, 'lexicon')  # 加载模型，第二个参数是您的外部词典文件路径
        self.tokenizer = segmentor



    def updateDenseVector(self, remote=True):
        # token列表
        token = set()
        with open(self.rawTextPath, 'r', encoding='utf-8') as file:
            csvReader = csv.reader(file)
            for i, line in enumerate(csvReader):
                # 将line的分词结果加入token
                if i != 0:
                    token = token.union(set(self.tokenizer.segment(line[2])))
        # 从远端服务器获取bert向量
        if remote == True:
            bc = BertClient(ip='10.100.31.1', port=5555)
            result = bc.encode(token)
            self.denseVector.update(dict(zip(token, result)))

    # 保存字典内容
    def writeDenseVector2TXT(self):
        with open(self.denseVectorPath, 'w', encoding='utf-8') as file:
            content = []
            for key, value in self.denseVector.items():
                content.append(key+' '+value+'\r\n')
            file.writelines(content)


class InteractiveTagging():
    """
    通过交互方式给数据打标签

    """
    def __init__(self):
        self.inforToBeTagged = ['Events', 'Money', 'Condition', 'SideEffect']
        self.corpusCSVPath = 'D:\\User\\Documents\\PycharmProjects\\GitHub\sequence_tagging-master-tf\\data\\保险责任.csv'
        self.taggedWord = 'D:\\User\\Documents\\PycharmProjects\\GitHub\sequence_tagging-master-tf\\data\\保险责任-taggedWord.txt'
        self.taggedSentence = 'D:\\User\\Documents\\PycharmProjects\\GitHub\sequence_tagging-master-tf\\data\\保险责任-taggedSentence.txt'
        segmentor = Segmentor()  # 初始化实例
        segmentor.load_with_lexicon(cws_model_path, 'lexicon')  # 加载模型，第二个参数是您的外部词典文件路径
        self.tokenizer = segmentor

    def wordTagging(self, startLine=0, endLine=1024):
        # 进行各信息段的首尾标记
        content = []
        with open(self.corpusCSVPath, 'r', encoding='utf-8') as file:
            csvReader = csv.reader(file)
            for index, line in enumerate(csvReader):
                # 允许分批标注(第0行是标题)
                if index <= startLine or index >= endLine:
                    continue
                text = re.sub(r'[\s]', '', line[2])  # bert无法处理空字符
                if len(text) == 0:
                    continue
                # 将line的分词结果加入token
                if index != 0:
                    tokenList = list(self.tokenizer.segment(text))
                    tagList = ['O'] * len(tokenList)
                    # 与人互动的方式确定B和I
                    for part in self.inforToBeTagged:
                        for temp in np.arange(len(tokenList)):
                            if temp % 10 == 0:
                                print(str(temp), ' - '.join(tokenList[temp:temp + 10]))
                        while 1:
                            # 人工指定起点和终点
                            B, I = map(int, re.split(r'[ ,，+-]', input("(space-separated)Begin & End of <%s>" % part)))
                            if B > I:
                                # 不存在
                                break
                            # 人工确认
                            humanCheck = input("(y/n)Is it true that %s segment is \r\n%s\r\n"
                                               % (part, ''.join(tokenList[B:I + 1])))
                            if humanCheck == 'y':
                                tagList[B:I + 1] = ['I-' + part] * (I - B + 1)
                                tagList[B] = 'B-' + part
                                # if input("If exist another <%s>?" % part) == 'y':  # 还存在其他event
                                #     continue
                                # else:
                                #     break
                    # 将token-tag写入文件
                    for pair in zip(tokenList, tagList):
                        content.append(pair[0] + ' ' + pair[1]+'\n')
                    content.append('\r\n')
                    wrFile = open(self.taggedWord, 'a', encoding='utf-8')
                    wrFile.writelines(content)
                    wrFile.close()

    def wordTagging_relation(self, startLine=0, endLine=1024):
        '''
        考虑到有多种关系：money、condition和sideeffect有属于某个events的关系
        同时，money可能也是在某个condition下的money，即和condition存在关系
        '''


    def sentenceTagging(self):
        content = []
        with open(self.corpusCSVPath, 'r', encoding='utf-8') as file:
            wrFile = open(self.taggedSentence, 'a', encoding='utf-8')
            csvReader = csv.reader(file)
            for index, line in enumerate(csvReader):
                text = re.sub(r'[\s]', '', line[2])  # bert无法处理空字符
                if len(text) == 0:
                    continue
                # 将line的分词结果加入token
                if index != 0:
                    sentenceList = SentenceSplitter.split(text)
                    tagList = ['O'] * len(sentenceList)
                    # 与人互动的方式确定B和I
                    for part in self.inforToBeTagged:
                        for temp in np.arange(len(sentenceList)):
                            if temp % 10 == 0:
                                print(str(temp), ' - '.join(sentenceList[temp:temp + 10]))
                        while 1:
                            # 人工指定起点和终点
                            B, I = map(int, re.split(r'[ ,，+-]', input("(space-separated)Begin & End of <%s>" % part)))
                            if B > I:
                                # 不存在
                                break
                            # 人工确认
                            humanCheck = input("(y/n)Is it true that %s segment is \r\n%s\r\n"
                                               % (part, ''.join(sentenceList[B:I + 1])))
                            if humanCheck == 'y':
                                tagList[B:I + 1] = ['I-' + part] * (I - B + 1)
                                tagList[B] = 'B-' + part
                                # if input("If exist another <%s>?" % part) == 'y':  # 还存在其他event
                                #     continue
                                # else:
                                #     break
                    # 将token-tag写入文件
                    for pair in zip(tagList, sentenceList):
                        content.append(pair[0] + ' ' + pair[1] + '\r\n')
                    content.append('\r\n')
                    wrFile.writelines(content)
                    wrFile.close()

    def taggingV2(self):
        '''
        input的格式为一个分好词的文档，
        :return:
        '''


class trainData():
    '''

    :return:
    '''
    def __init__(self):
        self.dataPath = 'D:\\User\\Documents\\PycharmProjects\\GitHubProjects\\BERT-NER-master\\保险责任-taggedWord.txt'
        self.infoDict = {}  # 各信息段的集合，用于保存不重复的信息段{'Events':[],'Condition':[],..}
        self.sentenceInfo = []  # 各句与其对应的信息起止点[(句子内容，{'Events':[(起，止)]})]

    # 从已标注的训练语料(ConLL格式)中，提取出各信息段。并根据tag分类
    # 测试OK
    def gatherInfor(self):
        with open(self.dataPath, 'r', encoding='utf-8') as rdFile:
            total = []
            tempSentence = []
            oneSentenceTag = []
            word = ''
            tag = ''
            sentenceBegin = 0
            for index, line in enumerate(rdFile.readlines()):
                if index == 236:
                    hello=1
                # 分句
                if re.sub(r'[\s]','',line) != '':
                    word, tag = line.split(' ')
                    tag = re.sub(r'[\s]','',tag)
                    tempSentence.append(word)
                    total.append(word)
                    if tag != 'O':
                        oneSentenceTag.append((tag, index))
                else:#一句结束
                    total.append(line)
                    info = {}
                    tokenEnd = -1
                    tokenBegin = -1

                    while len(oneSentenceTag)!=0:
                        t, i = oneSentenceTag.pop()
                        tokenEnd = i if i>tokenEnd else tokenEnd
                        if t.startswith('B'):
                            tokenBegin = i
                            tokenType = t.split('-')[-1]
                            if tokenType in info:
                                info[tokenType].append((tokenBegin-sentenceBegin, tokenEnd-sentenceBegin))
                            else:
                                info[tokenType]=[(tokenBegin-sentenceBegin, tokenEnd-sentenceBegin)]
                            if tokenType in self.infoDict:
                                if total[tokenBegin:tokenEnd+1] not in self.infoDict[tokenType]:
                                    self.infoDict[tokenType].append(total[tokenBegin:tokenEnd+1])
                            else:
                                self.infoDict[tokenType] = [total[tokenBegin:tokenEnd + 1]]
                            tokenEnd = -1
                            tokenBegin = -1
                    # 本句信息记录
                    self.sentenceInfo.append((tempSentence, info))

                    # 清空本句信息
                    tempSentence = []
                    oneSentenceTag = []
                    # 更新下句
                    sentenceBegin = index + 1

# 根据已有信息自动生成语料
def generateInfoCombination(infoDict, sentenceInfo, corpusPath):
    content = []
    for senIndex, sentence in enumerate(sentenceInfo):
        if len(sentence[0]) == 0:
            continue
        wrFile = open(corpusPath, 'a', encoding='utf-8')
        # 1.统计当前各句中info段的数量
        dic = dict().fromkeys(sentence[1].keys(), )   # {'Events':{'num':..,'permutation':[]}}
        for key, value in sentence[1].items():
            dic[key] = {'num':len(value)}
            # dic[key].update({'num':len(value)})
        # 2.对当前句子的每个info段生成permutation
        for key in dic.keys():
            # dic[key]['permutation'] = itertools.permutations(infoDict[key], dic[key]['num'])
            temp = list(itertools.combinations(infoDict[key], dic[key]['num']))
            dic[key]['combination'] = random.sample(temp, min(10, len(temp)))   # 从所有combination中随机抽取10个
        # 3.对当前句子各permution/combination进行组合，生成product
        heading = []
        content = None
        for key, value in dic.items():
            heading.append(key)
            if content:
                content = itertools.product(content, value['combination'])
            else:
                content = copy.copy(value['combination'])
        # 4.生成标注语料
        for index, item in enumerate(content):
            if index % 100 == 0:
                print("%dth sentence ,%dth generated data" % (senIndex, index))
            itemList = list(flatten(item))
            mapping = {}
            copyHeading = copy.copy(heading)
            while len(copyHeading)!=0:
                key = copyHeading.pop()
                num = dic[key]['num']
                value = [itemList.pop() for i in np.arange(num)]
                mapping[key] = value
            sentenceInfo2ConLL(mapping, sentence, wrFile)
        # 5.关闭文件
        wrFile.close()

    return 0

# 将info替换后的sentenceInfo格式的信息转换为ConLL格式
# infoCombination输入可能不含有所有info，例如本句需要的info不含有‘SideEffect’
def sentenceInfo2ConLL(infoCombination, sentence, wrFile):
    content = []
    # 格式转化
    for key, value in infoCombination.items():
        infoCombination[key] = list(value)

    # 建立本sentenceInfo各段info的倒排[(起，止，infoType)]
    temp = sentence[1]
    infoList = []
    for key, value in temp.items():
        for one in value:
            infoList.append((one[0], one[1], key))
    infoList = sorted(infoList, key=lambda x:x[1], reverse=True)
    # 反向遍历infoList：从后往前替换
    substituted = list(map(lambda x:x+' -O',sentence[0]))
    for item in infoList:
        start = item[0]
        end = item[1]+1
        infoType = item[2]
        line = list(map(lambda x:x+' I-'+infoType, infoCombination[infoType].pop()))
        line[0] = ' '.join([line[0].split()[0], 'B-'+infoType])
        substituted[start:end] = line
    content.append('\n'.join(substituted)+'\n')
    # 保存
    wrFile.writelines(content)
    wrFile.write('\n')


    return 0


def flatten(items, ignore_types=(str, bytes, list)):
    for x in items:
        if isinstance(x, Iterable) and not isinstance(x, ignore_types):
            yield from flatten(x)
        else:
            yield x









class CoNLLDataset(object):
    """Class that iterates over CoNLL Dataset

    __iter__ method yields a tuple (words, tags)
        words: list of raw words
        tags: list of raw tags

    If processing_word and processing_tag are not None,
    optional preprocessing is appplied

    Example:
        ```python
        data = CoNLLDataset(filename)
        for sentence, tags in data:
            pass
        ```

    """
    def __init__(self, filename, processing_word=None, processing_tag=None,
                 max_iter=None):
        """
        Args:
            filename: path to the file
            processing_words: (optional) function that takes a word as input
            processing_tags: (optional) function that takes a tag as input
            max_iter: (optional) max number of sentences to yield

        """
        self.filename = filename
        self.processing_word = processing_word
        self.processing_tag = processing_tag
        self.max_iter = max_iter
        self.length = None


    def __iter__(self):
        niter = 0
        with open(self.filename) as f:
            words, tags = [], []
            for line in f:
                line = line.strip()
                if (len(line) == 0 or line.startswith("-DOCSTART-")):
                    if len(words) != 0:
                        niter += 1
                        if self.max_iter is not None and niter > self.max_iter:
                            break
                        yield words, tags
                        words, tags = [], []
                else:
                    ls = line.split(' ')
                    word, tag = ls[0],ls[1]
                    if self.processing_word is not None:
                        word = self.processing_word(word)
                    if self.processing_tag is not None:
                        tag = self.processing_tag(tag)
                    words += [word]
                    tags += [tag]


    def __len__(self):
        """Iterates once over the corpus to set and store length"""
        if self.length is None:
            self.length = 0
            for _ in self:
                self.length += 1

        return self.length


def get_vocabs(datasets):
    """Build vocabulary from an iterable of datasets objects

    Args:
        datasets: a list of dataset objects

    Returns:
        a set of all the words in the dataset

    """
    print("Building vocab...")
    vocab_words = set()
    vocab_tags = set()
    for dataset in datasets:
        for words, tags in dataset:
            vocab_words.update(words)
            vocab_tags.update(tags)
    print("- done. {} tokens".format(len(vocab_words)))
    return vocab_words, vocab_tags


def get_char_vocab(dataset):
    """Build char vocabulary from an iterable of datasets objects

    Args:
        dataset: a iterator yielding tuples (sentence, tags)

    Returns:
        a set of all the characters in the dataset

    """
    vocab_char = set()
    for words, _ in dataset:
        for word in words:
            vocab_char.update(word)

    return vocab_char


def get_glove_vocab(filename):
    """Load vocab from file

    Args:
        filename: path to the glove vectors

    Returns:
        vocab: set() of strings
    """
    print("Building vocab...")
    vocab = set()
    with open(filename) as f:
        for line in f:
            word = line.strip().split(' ')[0]
            vocab.add(word)
    print("- done. {} tokens".format(len(vocab)))
    return vocab


def write_vocab(vocab, filename):
    """Writes a vocab to a file

    Writes one word per line.

    Args:
        vocab: iterable that yields word
        filename: path to vocab file

    Returns:
        write a word per line

    """
    print("Writing vocab...")
    with open(filename, "w") as f:
        for i, word in enumerate(vocab):
            if i != len(vocab) - 1:
                f.write("{}\n".format(word))
            else:
                f.write(word)
    print("- done. {} tokens".format(len(vocab)))


def load_vocab(filename):
    """Loads vocab from a file

    Args:
        filename: (string) the format of the file must be one word per line.

    Returns:
        d: dict[word] = index

    """
    try:
        d = dict()
        with open(filename) as f:
            for idx, word in enumerate(f):
                word = word.strip()
                d[word] = idx

    except IOError:
        raise MyIOError(filename)
    return d


def export_trimmed_glove_vectors(vocab, glove_filename, trimmed_filename, dim):
    """Saves glove vectors in numpy array

    Args:
        vocab: dictionary vocab[word] = index
        glove_filename: a path to a glove file
        trimmed_filename: a path where to store a matrix in npy
        dim: (int) dimension of embeddings

    """
    embeddings = np.zeros([len(vocab), dim])
    with open(glove_filename) as f:
        for line in f:
            line = line.strip().split(' ')
            word = line[0]
            embedding = [float(x) for x in line[1:]]
            if word in vocab:
                word_idx = vocab[word]
                embeddings[word_idx] = np.asarray(embedding)

    np.savez_compressed(trimmed_filename, embeddings=embeddings)


def get_trimmed_glove_vectors(filename):
    """
    Args:
        filename: path to the npz file

    Returns:
        matrix of embeddings (np array)

    """
    try:
        with np.load(filename) as data:
            return data["embeddings"]

    except IOError:
        raise MyIOError(filename)


def get_processing_word(vocab_words=None, vocab_chars=None,
                    lowercase=False, chars=False, allow_unk=True):
    """Return lambda function that transform a word (string) into list,
    or tuple of (list, id) of int corresponding to the ids of the word and
    its corresponding characters.

    Args:
        vocab: dict[word] = idx

    Returns:
        f("cat") = ([12, 4, 32], 12345)
                 = (list of char ids, word id)

    """
    def f(word):
        # 0. get chars of words
        if vocab_chars is not None and chars == True:
            char_ids = []
            for char in word:
                # ignore chars out of vocabulary
                if char in vocab_chars:
                    char_ids += [vocab_chars[char]]

        # 1. preprocess word
        if lowercase:
            word = word.lower()
        if word.isdigit():
            word = NUM

        # 2. get id of word
        if vocab_words is not None:
            if word in vocab_words:
                word = vocab_words[word]
            else:
                if allow_unk:
                    word = vocab_words[UNK]
                else:
                    raise Exception("Unknow key is not allowed. Check that "\
                                    "your vocab (tags?) is correct")

        # 3. return tuple char ids, word id
        if vocab_chars is not None and chars == True:
            return char_ids, word
        else:
            return word

    return f


def _pad_sequences(sequences, pad_tok, max_length):
    """
    Args:
        sequences: a generator of list or tuple
        pad_tok: the char to pad with

    Returns:
        a list of list where each sublist has same length
    """
    sequence_padded, sequence_length = [], []

    for seq in sequences:
        seq = list(seq)
        seq_ = seq[:max_length] + [pad_tok]*max(max_length - len(seq), 0)
        sequence_padded +=  [seq_]
        sequence_length += [min(len(seq), max_length)]

    return sequence_padded, sequence_length


def pad_sequences(sequences, pad_tok, nlevels=1):
    """
    Args:
        sequences: a generator of list or tuple
        pad_tok: the char to pad with
        nlevels: "depth" of padding, for the case where we have characters ids

    Returns:
        a list of list where each sublist has same length

    """
    if nlevels == 1:
        max_length = max(map(lambda x : len(x), sequences))
        sequence_padded, sequence_length = _pad_sequences(sequences,
                                            pad_tok, max_length)

    elif nlevels == 2:
        max_length_word = max([max(map(lambda x: len(x), seq))
                               for seq in sequences])
        sequence_padded, sequence_length = [], []
        for seq in sequences:
            # all words are same length now
            sp, sl = _pad_sequences(seq, pad_tok, max_length_word)
            sequence_padded += [sp]
            sequence_length += [sl]

        max_length_sentence = max(map(lambda x : len(x), sequences))
        sequence_padded, _ = _pad_sequences(sequence_padded,
                [pad_tok]*max_length_word, max_length_sentence)
        sequence_length, _ = _pad_sequences(sequence_length, 0,
                max_length_sentence)

    return sequence_padded, sequence_length


def minibatches(data, minibatch_size):
    """
    Args:
        data: generator of (sentence, tags) tuples
        minibatch_size: (int)

    Yields:
        list of tuples

    """
    x_batch, y_batch = [], []
    for (x, y) in data:
        if len(x_batch) == minibatch_size:
            yield x_batch, y_batch
            x_batch, y_batch = [], []

        if type(x[0]) == tuple:
            x = zip(*x)
        x_batch += [x]
        y_batch += [y]

    if len(x_batch) != 0:
        yield x_batch, y_batch


def get_chunk_type(tok, idx_to_tag):
    """
    Args:
        tok: id of token, ex 4
        idx_to_tag: dictionary {4: "B-PER", ...}

    Returns:
        tuple: "B", "PER"

    """
    tag_name = idx_to_tag[tok]
    tag_class = tag_name.split('-')[0]
    tag_type = tag_name.split('-')[-1]
    return tag_class, tag_type


def get_chunks(seq, tags):
    """Given a sequence of tags, group entities and their position

    Args:
        seq: [4, 4, 0, 0, ...] sequence of labels
        tags: dict["O"] = 4

    Returns:
        list of (chunk_type, chunk_start, chunk_end)

    Example:
        seq = [4, 5, 0, 3]
        tags = {"B-PER": 4, "I-PER": 5, "B-LOC": 3}
        result = [("PER", 0, 2), ("LOC", 3, 4)]

    """
    default = tags[NONE]
    idx_to_tag = {idx: tag for tag, idx in tags.items()}
    chunks = []
    chunk_type, chunk_start = None, None
    for i, tok in enumerate(seq):
        # End of a chunk 1
        if tok == default and chunk_type is not None:
            # Add a chunk.
            chunk = (chunk_type, chunk_start, i)
            chunks.append(chunk)
            chunk_type, chunk_start = None, None

        # End of a chunk + start of a chunk!
        elif tok != default:
            tok_chunk_class, tok_chunk_type = get_chunk_type(tok, idx_to_tag)
            if chunk_type is None:
                chunk_type, chunk_start = tok_chunk_type, i
            elif tok_chunk_type != chunk_type or tok_chunk_class == "B":
                chunk = (chunk_type, chunk_start, i)
                chunks.append(chunk)
                chunk_type, chunk_start = tok_chunk_type, i
        else:
            pass

    # end condition
    if chunk_type is not None:
        chunk = (chunk_type, chunk_start, len(seq))
        chunks.append(chunk)

    return chunks


