from numpy import random
import numpy as np
import os, time, sys
import tensorflow as tf
from tensorflow.contrib.rnn import LSTMCell
from tensorflow.contrib.crf import crf_log_likelihood
from tensorflow.contrib.crf import viterbi_decode
from models_tf_seqTagging.data import pad_sequences, batch_yield, batch_yield_train, read_dictionary, random_embedding, getConditionalProbFromList, read_corpus
from models_tf_seqTagging.utils import get_logger, viterbi_decode_LU, getSoftmax
from models_tf_seqTagging.eval import conlleval


class BiLSTM_ATTENTION_CRF(object):
    def __init__(self, args, tag2label, paths, config):
        # embedding
        word2id = read_dictionary(os.path.join('.', args.train_data, 'wholeword2id123.pkl'))
        if args.pretrain_embedding == 'random':
            embeddings = random_embedding(word2id, args.embedding_dim)
        elif args.pretrain_embedding == 'BERT':
            embedding_path = os.path.join(args.train_data, 'bertEmbedding123.npy')
            embeddings = np.array(np.load(embedding_path), dtype='float32')
        else:
            embedding_path = os.path.join(args.train_data, 'pretrain_embedding.npy')
            embeddings = np.array(np.load(embedding_path), dtype='float32')

        self.batch_size = args.batch_size
        self.epoch_num = args.epoch
        self.hidden_dim = args.hidden_dim
        self.embeddings = embeddings
        self.CRF = args.CRF
        self.update_embedding = args.update_embedding
        self.dropout_keep_prob = args.dropout
        self.optimizer = args.optimizer
        self.lr = args.lr
        self.clip_grad = args.clip
        self.tag2label = tag2label
        self.num_tags = len(tag2label)
        self.vocab = word2id
        self.shuffle = args.shuffle
        self.model_path = paths['model_path']
        self.summary_path = paths['summary_path']
        self.logger = get_logger(paths['log_path'])
        self.result_path = paths['result_path']
        self.config = config
        # 人工定义CRF的transition matrix
        _, _, tagList = read_corpus(args.labeledTXTPath_ConLL)
        self.tagInsuranceTrans, self.firstTagProb = getConditionalProbFromList(tagList, tag2label)
        self.firstTagProb += (random.random(size=self.firstTagProb.shape)*0.001)
        self.firstTagProb = getSoftmax(self.firstTagProb)

    def build_graph(self):
        self.add_placeholders()
        self.lookup_layer_op()
        self.biLSTM_layer_op()
        self.attention_op1()
        self.fullyConnected_op()
        self.softmax_pred_op()
        self.loss_op()
        self.trainstep_op()

    def add_placeholders(self):
        self.word_ids = tf.placeholder(tf.int32, shape=[None, None], name="word_ids")
        self.labels = tf.placeholder(tf.int32, shape=[None, None], name="labels")
        self.sequence_lengths = tf.placeholder(tf.int32, shape=[None], name="sequence_lengths")

        self.dropout_pl = tf.placeholder(dtype=tf.float32, shape=[], name="dropout")
        self.lr_pl = tf.placeholder(dtype=tf.float32, shape=[], name="lr")

    def lookup_layer_op(self):
        with tf.variable_scope("words"):
            _word_embeddings = tf.Variable(self.embeddings,
                                           dtype=tf.float32,
                                           trainable=self.update_embedding,
                                           name="_word_embeddings")
            word_embeddings = tf.nn.embedding_lookup(params=_word_embeddings,
                                                     ids=self.word_ids,
                                                     name="word_embeddings")
        self.word_embeddings = tf.nn.dropout(word_embeddings, self.dropout_pl)

    def biLSTM_layer_op(self):
        with tf.variable_scope("bi-lstm"):
            cell_fw = LSTMCell(self.hidden_dim)
            cell_bw = LSTMCell(self.hidden_dim)
            (output_fw_seq, output_bw_seq), _ = tf.nn.bidirectional_dynamic_rnn(
                cell_fw=cell_fw,
                cell_bw=cell_bw,
                inputs=self.word_embeddings,
                sequence_length=self.sequence_lengths,
                dtype=tf.float32)
        self.BiLSTMOutput = tf.concat([output_fw_seq, output_bw_seq], axis=-1)
        self.BiLSTMOutput = tf.nn.dropout(self.BiLSTMOutput, self.dropout_pl)

    def attention_op(self):
        '''
        :input: BiLSTMOutput(?,?,2*self.hidden_dims)
        :return:
        '''
        # Attention
        with tf.variable_scope('attention'):
            # get allignment matrix alphas:(句子数，句子长度，句子长度)
            '''
            BiLSTM（句子数，句子长度,hidden_dims）:[token1,token2,token3,...,tokenn]
            V1=[[t1,t1,t1,...,t1],
                [t2,t2,t2,...,t2],
                ...
                [tn,tn,tn,...,tn]]
            V2=[[t1,t2,t3,...,tn],
                [t1,t2,t3,...,tn],
                ...
                [t1,t2,t3,...,tn]]
            '''
            shape = self.BiLSTMOutput.shape
            batchSize = shape[0]
            tokenNum = shape[1]
            hiddenStates = shape[2]

            #V1 = tf.reshape(self.BiLSTMOutput, [batchSize,tokenNum,1,hiddenStates])
            # V1 = tf.tile(V1, [1,1,tokenNum,1])
            V1 = tf.expand_dims(self.BiLSTMOutput, 2)

            #V2 = tf.reshape(self.BiLSTMOutput, [batchSize,1,tokenNum,hiddenStates])
            #V2 = tf.tile(V2, [1, tokenNum, 1, 1])
            V2 = tf.expand_dims(self.BiLSTMOutput, 1)
            # 获得allignment score
            b = V1*V2
            b_sum = tf.reduce_sum(b, -1)
            '''
            b_sum = tf.reduce_sum(b, -1)
            # 获得allignment probability
            b_prob = tf.reduce_sum(b_sum, -1)
            b_prob = tf.expand_dims(b_prob, -1)
            #b_prob = tf.tile(b_prob, [1, 1, 3])
            b_prob = b_sum / b_prob
            '''
            b_prob = tf.nn.softmax(b_sum, -1)
            # 获得weighted sum(也就是context)
            b_prob_ex = tf.expand_dims(b_prob, -1)
            output_ex = tf.expand_dims(self.BiLSTMOutput, 1)
            context = output_ex * b_prob_ex
            context = tf.reduce_sum(context, 2)

        self.attContext = context
        self.alphas = b_prob

    def attention_op1(self):
        '''
        借鉴《An Introductory Survey on Attention Mechanisms in NLP Problems》,Dichao Hu中self-attention
        :return:
        '''
        '''
              BiLSTM（句子数，句子长度,hidden_dims）:[token1,token2,token3,...,tokenn]
              V1=[[t1,t1,t1,...,t1],
                  [t2,t2,t2,...,t2],
                  ...
                  [tn,tn,tn,...,tn]]
              V2=[[t1,t2,t3,...,tn],
                  [t1,t2,t3,...,tn],
                  ...
                  [t1,t2,t3,...,tn]]
        '''
        with tf.variable_scope('attention'):
            shape = tf.shape(self.BiLSTMOutput)
            batchSize = shape[0]
            tokenNum = shape[1]
            hiddenStates = shape[2]

            V1 = tf.expand_dims(self.BiLSTMOutput, 2)
            V1_ = tf.tile(V1, [1,1,tokenNum,1])
            V2 = tf.expand_dims(self.BiLSTMOutput, 1)
            V2_ = tf.tile(V2, [1, tokenNum, 1, 1])
            # 将特征拼接
            try:
                V12 = tf.concat([V1_, V2_], axis=-1)
            except:
                a=1
            # 神经网络
            W_att = tf.get_variable(name="W_att",
                                shape=[(2+2) * self.hidden_dim,1],
                                initializer=tf.contrib.layers.xavier_initializer(),
                                dtype=tf.float32)
            b_att = tf.get_variable(name="b_att",
                                shape=[1],
                                initializer=tf.zeros_initializer(),
                                dtype=tf.float32)

            V12_ = tf.reshape(V12, [-1, (2+2) * self.hidden_dim])
            # 获得allignment score
            allignMatrix = tf.matmul(V12_, W_att) + b_att
            allignMatrix = tf.reshape(allignMatrix, shape=[batchSize, tokenNum, tokenNum, 1])
            allignMatrix = tf.nn.relu(allignMatrix)
            allignMatrix = tf.nn.softmax(allignMatrix, 2)
            # 获得weighted sum(也就是context)
            output_ex = tf.expand_dims(self.BiLSTMOutput, 1)
            context = output_ex * allignMatrix
            context = tf.reduce_sum(context, 2)

        self.attContext = context
        self.alphas = allignMatrix

    def fullyConnected_op(self):
        # Fully connected layer
        with tf.variable_scope("proj"):
            W = tf.get_variable(name="W",
                                shape=[(2+2) * self.hidden_dim, self.num_tags],
                                initializer=tf.contrib.layers.xavier_initializer(),
                                dtype=tf.float32)

            b = tf.get_variable(name="b",
                                shape=[self.num_tags],
                                # initializer=tf.contrib.layers.xavier_initializer(),
                                initializer=tf.zeros_initializer(),
                                # initializer=tf.ones_initializer(),
                                dtype=tf.float32)

            context = tf.reshape(self.attContext, [-1, 2*self.hidden_dim])
            BiLSTMOutput = tf.reshape(self.BiLSTMOutput, [-1, 2*self.hidden_dim])
            feature = tf.concat([BiLSTMOutput, context], -1)
            pred = tf.matmul(feature, W) + b
            # pred = tf.tanh(pred)
            pred = tf.nn.relu(pred)

            s = tf.shape(self.BiLSTMOutput)
            self.logits = tf.reshape(pred, [-1, s[1], self.num_tags])

    def loss_op(self):
        if self.CRF:
            # 人工自定义CRF转移矩阵
            self.transition_params = tf.Variable(self.tagInsuranceTrans, name='transitions', dtype=tf.float32)
            log_likelihood, self.transition_params = crf_log_likelihood(inputs=self.logits,
                                                                   tag_indices=self.labels,
                                                                   sequence_lengths=self.sequence_lengths,
                                                                   transition_params=self.transition_params)
            self.loss = -tf.reduce_mean(log_likelihood)
            self.log_likelihood = log_likelihood
        else:
            losses = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=self.logits,
                                                                    labels=self.labels)
            mask = tf.sequence_mask(self.sequence_lengths)
            losses = tf.boolean_mask(losses, mask)
            self.loss = tf.reduce_mean(losses)

        tf.summary.scalar("loss", self.loss)

    def softmax_pred_op(self):
        if not self.CRF:
            self.labels_softmax_ = tf.argmax(self.logits, axis=-1)
            self.labels_softmax_ = tf.cast(self.labels_softmax_, tf.int32)

    def trainstep_op(self):
        with tf.variable_scope("train_step"):
            self.global_step = tf.Variable(0, name="global_step", trainable=False)
            if self.optimizer == 'Adam':
                optim = tf.train.AdamOptimizer(learning_rate=self.lr_pl)
            elif self.optimizer == 'Adadelta':
                optim = tf.train.AdadeltaOptimizer(learning_rate=self.lr_pl)
            elif self.optimizer == 'Adagrad':
                optim = tf.train.AdagradOptimizer(learning_rate=self.lr_pl)
            elif self.optimizer == 'RMSProp':
                optim = tf.train.RMSPropOptimizer(learning_rate=self.lr_pl)
            elif self.optimizer == 'Momentum':
                optim = tf.train.MomentumOptimizer(learning_rate=self.lr_pl, momentum=0.9)
            elif self.optimizer == 'SGD':
                optim = tf.train.GradientDescentOptimizer(learning_rate=self.lr_pl)
            else:
                optim = tf.train.GradientDescentOptimizer(learning_rate=self.lr_pl)

            # optim.minimize就是compute_gradients和apply_gradients的操作组合
            grads_and_vars = optim.compute_gradients(self.loss)
            grads_and_vars_clip = [[tf.clip_by_value(g, -self.clip_grad, self.clip_grad), v] for g, v in grads_and_vars]#把梯度控制在范围内
            self.train_op = optim.apply_gradients(grads_and_vars_clip, global_step=self.global_step)

    def init_op(self):
        self.init_op = tf.global_variables_initializer()
        self.sess.run(self.init_op)

    def add_summary(self, sess):
        """

        :param sess:
        :return:
        """
        self.merged = tf.summary.merge_all()
        self.file_writer = tf.summary.FileWriter(self.summary_path, sess.graph)

    def train(self, sess, train, dev):
        """

        :param train:
        :param dev:
        :return:
        """
        saver = tf.train.Saver(tf.global_variables())
        self.add_summary(sess)

        for epoch in range(self.epoch_num):
            self.run_one_epoch(sess, train, dev, self.tag2label, epoch, saver)

    def test(self, test):
        saver = tf.train.Saver()
        with tf.Session(config=self.config) as sess:
            self.logger.info('=========== testing ===========')
            saver.restore(sess, self.model_path)
            label_list, seq_len_list = self.dev_one_epoch(sess, test)
            self.evaluate(label_list, seq_len_list, test)

    def demo_one(self, sess, sent):
        """

        :param sess:
        :param sent:
        :return:
        """
        label_list = []
        for seqs, labels in batch_yield(sent, self.batch_size, self.vocab, self.tag2label, shuffle=False):
            label_list_, _ = self.predict_one_batch(sess, seqs)
            label_list.extend(label_list_)
        label2tag = {}
        for tag, label in self.tag2label.items():
            label2tag[label] = tag if label != 0 else label
        tag = [label2tag[label] for label in label_list[0]]
        return tag

    # 废除
    # def demo_one_LU(self, sess, sent):
    #     """
    #     返回参数多个：tag的uncertainty度，或置信度belief
    #     :param sess:
    #     :param sent:
    #     :return:
    #     """
    #     saver = tf.train.Saver()
    #     self.logger.info('=========== demoing ===========')
    #     saver.restore(sess, self.model_path)
    #     label_list = []
    #     for seqs in batch_yield_train(sent, self.batch_size, self.vocab, shuffle=False):
    #         label_list_, seq_len_list, viterbi_score_List = self.predict_one_batch(sess, seqs)
    #         label_list.extend(label_list_)
    #     label2tag = {}
    #     for tag, label in self.tag2label.items():
    #         label2tag[label] = tag if label != 0 else label
    #     tag = [label2tag[label] for label in label_list[0]]
    #     # 原始返回是return tag
    #     return tag, seq_len_list, viterbi_score_List

    def demo_one_LU(self, sess, sent, useExistedModel=True):
        """
        demo_one_LU会恢复已有的模型，但是此函数从0模型开始预测
        同时，batch_yield修改为batch_yield_train
        :param sess:
        :param sent:
        :param useExistedModel:True，使用已有模型预测；False：使用随机模型预测
        :return:
        """
        if useExistedModel == True:
            ckpt_file = tf.train.latest_checkpoint(self.model_path)
            print(ckpt_file)
            saver = tf.train.Saver()
            saver.restore(sess, ckpt_file)
        self.logger.info('=========== predicting ===========')
        label_list = []
        viterbi_score_List = []
        tag = []
        seq_len_list = []
        # 按batch预测
        for seqs in batch_yield_train(sent, self.batch_size, self.vocab, shuffle=False):
            label_list_, seq_len_list_, viterbi_score_List_ = self.predict_one_batch(sess, seqs)
            label_list.extend(label_list_)
            viterbi_score_List.extend(viterbi_score_List_)
            seq_len_list.extend(seq_len_list_)
        label2tag = {}
        # 生成label2tag
        for key, value in self.tag2label.items():
            label2tag[value] = key if value != 0 else value
        # 将预测label转化为tag
        for label in label_list:
            tag_ = [label2tag[x] for x in label]
            tag.append(tag_)

        # 原始返回是return tag
        return tag, seq_len_list, viterbi_score_List

    def run_one_epoch(self, sess, train, dev, tag2label, epoch, saver):
        """

        :param sess:
        :param train:
        :param dev:
        :param tag2label:
        :param epoch:
        :param saver:
        :return:
        """
        num_batches = (len(train) + self.batch_size - 1) // self.batch_size

        start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        batches = batch_yield(train, self.batch_size, self.vocab, self.tag2label, shuffle=self.shuffle)
        for step, (seqs, labels) in enumerate(batches):

            sys.stdout.write(' processing: {} batch / {} batches.'.format(step + 1, num_batches) + '\r')
            step_num = epoch * num_batches + step + 1
            feed_dict, _ = self.get_feed_dict(seqs, labels, self.lr, self.dropout_keep_prob)
            if self.CRF:
                _, loss_train, summary, step_num_, log_likelihood, logits, labels, transition_params = \
                    sess.run([self.train_op, self.loss, self.merged, self.global_step, self.log_likelihood, self.logits, self.labels, self.transition_params],
                                                             feed_dict=feed_dict)
                # LU：原本的CRF不做viterbi译码，只预测每个tag的可能性，这里LU加入译码，以计算token的accuracy
                predictLabelList = []
                for logit in logits:
                    viterbi_seq, _ = viterbi_decode_LU(logit, transition_params, self.firstTagProb)
                    predictLabelList.append(viterbi_seq)
                predictLabelList = np.array(predictLabelList).flatten()
                labels = labels.flatten()
            else:
                _, loss_train, summary, step_num_, logits, labels = \
                    sess.run([self.train_op, self.loss, self.merged, self.global_step, self.logits,
                              self.labels],
                             feed_dict=feed_dict)
                # LU：原本的CRF不做viterbi译码，只预测每个tag的可能性，这里LU加入译码，以计算token的accuracy
                predictLabelList = sess.run(self.labels_softmax_, feed_dict=feed_dict).flatten()
                labels = labels.flatten()

            # 计算token accuracy
            hitNum = 0
            totalTokenNum = len(labels)
            for i in np.arange(totalTokenNum):
                if predictLabelList[i] == labels[i]:
                    hitNum += 1
            tokenAccuracy = round(hitNum*100.0/totalTokenNum,2)
            #打印
            if step + 1 == 1 or (step + 1) % 10 == 0 or step + 1 == num_batches:
                self.logger.info('{} epoch {}, step {}, loss: {:.4}, tokenAccuracy:{}%, global_step: {}'.format(start_time, epoch + 1, step + 1,
                                                                                loss_train, tokenAccuracy, step_num))

            self.file_writer.add_summary(summary, step_num)

            if step + 1 == num_batches:
                saver.save(sess, self.model_path, global_step=step_num)

        self.logger.info('===========validation / test===========')
        label_list_dev, seq_len_list_dev = self.dev_one_epoch(sess, dev)
        self.evaluate(label_list_dev, seq_len_list_dev, dev, epoch)

    def get_feed_dict(self, seqs, labels=None, lr=None, dropout=None):
        """

        :param seqs:
        :param labels:
        :param lr:
        :param dropout:
        :return: feed_dict
        """
        word_ids, seq_len_list = pad_sequences(seqs, pad_mark=0)

        feed_dict = {self.word_ids: word_ids,
                     self.sequence_lengths: seq_len_list}
        if labels is not None:
            labels_, _ = pad_sequences(labels, pad_mark=0)
            feed_dict[self.labels] = labels_
        if lr is not None:
            feed_dict[self.lr_pl] = lr
        if dropout is not None:
            feed_dict[self.dropout_pl] = dropout

        return feed_dict, seq_len_list

    def dev_one_epoch(self, sess, dev):
        """

        :param sess:
        :param dev:
        :return:
        """
        label_list, seq_len_list = [], []
        for seqs, labels in batch_yield(dev, self.batch_size, self.vocab, self.tag2label, shuffle=False):
            label_list_, seq_len_list_, _ = self.predict_one_batch(sess, seqs)
            label_list.extend(label_list_)
            seq_len_list.extend(seq_len_list_)
        return label_list, seq_len_list

    def predict_one_batch(self, sess, seqs):
        """

        :param sess:
        :param seqs:
        :return: label_list
                 seq_len_list
        """
        feed_dict, seq_len_list = self.get_feed_dict(seqs, dropout=1.0) # 原来dropout是1.0？对，应该是1.0，因为测试时dropout对每个节点都应该使用

        if self.CRF:
            logits, transition_params = sess.run([self.logits, self.transition_params],
                                                 feed_dict=feed_dict)
            label_list = []
            viterbi_score_List = []
            for logit, seq_len in zip(logits, seq_len_list):
                viterbi_seq, viterbi_score = viterbi_decode_LU(logit[:seq_len], transition_params, self.firstTagProb)
                label_list.append(viterbi_seq)
                viterbi_score_List.append(viterbi_score)
            # 原始返回是return label_list, seq_len_list
            return label_list, seq_len_list, viterbi_score_List

        else:
            label_list = sess.run(self.labels_softmax_, feed_dict=feed_dict)
            return label_list, seq_len_list, 0

    def evaluate(self, label_list, seq_len_list, data, epoch=None):
        """

        :param label_list:
        :param seq_len_list:
        :param data:
        :param epoch:
        :return:
        """
        label2tag = {}
        for tag, label in self.tag2label.items():
            label2tag[label] = tag if label != 0 else label

        model_predict = []
        for label_, (sent, tag) in zip(label_list, data):
            tag_ = [label2tag[label__] for label__ in label_]
            sent_res = []
            if  len(label_) != len(sent):
                print(sent)
                print(len(label_))
                print(tag)
            for i in range(len(sent)):
                sent_res.append([sent[i], tag[i], tag_[i]])
            model_predict.append(sent_res)
        epoch_num = str(epoch+1) if epoch != None else 'test'
        label_path = os.path.join(self.result_path, 'label_' + epoch_num)
        metric_path = os.path.join(self.result_path, 'result_metric_' + epoch_num)
        for _ in conlleval(model_predict, label_path, metric_path):
            self.logger.info(_)



